package com.centralhex.jarvis.core

import com.centralhex.jarvis.ui.components.OrbState
import kotlinx.coroutines.flow.MutableStateFlow

/**
 * Petit "tableau d'affichage" partagé : le service d'écoute y écrit ce que fait JARVIS
 * (il écoute, il réfléchit, il parle…) et l'écran d'accueil, l'écran de réveil et la boule
 * flottante l'affichent en temps réel.
 */
object JarvisBus {
    val state = MutableStateFlow(OrbState.IDLE)
    val line = MutableStateFlow("")
}
