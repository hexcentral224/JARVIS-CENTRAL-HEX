package com.centralhex.jarvis

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.centralhex.jarvis.ui.HomeScreen
import com.centralhex.jarvis.ui.JarvisViewModel
import com.centralhex.jarvis.ui.RulesScreen
import com.centralhex.jarvis.ui.SettingsScreen
import com.centralhex.jarvis.ui.theme.JarvisTheme

private data class Tab(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)
private val TABS = listOf(
    Tab("home", "Accueil", Icons.Filled.Home),
    Tab("rules", "Automatisations", Icons.Filled.Tune),
    Tab("settings", "Réglages", Icons.Filled.Settings)
)

class MainActivity : ComponentActivity() {

    private val viewModel: JarvisViewModel by viewModels()

    private val requestPermissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { /* les fonctions concernées basculent automatiquement en mode "manuel" si refusées */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        askPermissions()

        setContent {
            val state by viewModel.state.collectAsState()
            JarvisTheme(dark = state.settings.darkTheme) {
                Surface(modifier = Modifier.fillMaxSize(), color = androidx.compose.material3.MaterialTheme.colorScheme.background) {
                    val navController = rememberNavController()
                    val backStack by navController.currentBackStackEntryAsState()
                    val currentRoute = backStack?.destination?.route

                    Scaffold(
                        bottomBar = {
                            NavigationBar {
                                TABS.forEach { tab ->
                                    NavigationBarItem(
                                        selected = currentRoute == tab.route,
                                        onClick = {
                                            navController.navigate(tab.route) {
                                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                                launchSingleTop = true
                                                restoreState = true
                                            }
                                        },
                                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                                        label = { Text(tab.label) }
                                    )
                                }
                            }
                        }
                    ) { padding ->
                        androidx.compose.foundation.layout.Box(Modifier.padding(padding)) {
                            NavHost(navController = navController, startDestination = "home") {
                                composable("home") {
                                    HomeScreen(
                                        viewModel = viewModel,
                                        onOpenRules = { navController.navigate("rules") },
                                        onOpenSettings = { navController.navigate("settings") }
                                    )
                                }
                                composable("settings") {
                                    val s by viewModel.state.collectAsState()
                                    SettingsScreen(
                                        settings = s.settings,
                                        onSave = { viewModel.updateSettings(it) },
                                        onOpenRules = { navController.navigate("rules") },
                                        onBack = { navController.popBackStack() }
                                    )
                                }
                                composable("rules") {
                                    val s by viewModel.state.collectAsState()
                                    RulesScreen(
                                        rules = s.rules,
                                        onAdd = viewModel::addRule,
                                        onDelete = viewModel::deleteRule,
                                        onBack = { navController.popBackStack() }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private fun askPermissions() {
        val perms = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.SEND_SMS
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms += Manifest.permission.POST_NOTIFICATIONS
        }
        requestPermissions.launch(perms.toTypedArray())
    }
}
