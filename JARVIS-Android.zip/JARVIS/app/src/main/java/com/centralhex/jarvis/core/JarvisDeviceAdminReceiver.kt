package com.centralhex.jarvis.core

import android.app.admin.DeviceAdminReceiver

/**
 * N'existe que pour permettre la commande "verrouille l'écran".
 * Ne touche à rien d'autre : pas d'accès aux messages, aux fichiers, etc.
 * L'utilisateur doit l'activer lui-même depuis Réglages ▸ "Verrouillage à distance".
 */
class JarvisDeviceAdminReceiver : DeviceAdminReceiver()
