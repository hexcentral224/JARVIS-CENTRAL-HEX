package com.centralhex.jarvis.core

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

/**
 * Fait écouter et parler JARVIS. Deux moteurs fournis par Android lui-même
 * (aucun service externe, aucune clé nécessaire) :
 *  - SpeechRecognizer : transforme la voix en texte
 *  - TextToSpeech     : transforme le texte en voix
 */
class VoiceManager(
    private val context: Context,
    private val onResult: (String) -> Unit,
    private val onListeningChange: (Boolean) -> Unit = {},
    private val onError: (String) -> Unit = {}
) {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    init {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.FRENCH
                ttsReady = true
            }
        }
    }

    fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onError("La reconnaissance vocale n'est pas disponible sur cet appareil.")
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { onListeningChange(true) }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { onListeningChange(false) }
                override fun onError(error: Int) {
                    onListeningChange(false)
                    onError(
                        when (error) {
                            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER ->
                                "Pas de connexion : télécharge le français hors ligne (Paramètres ▸ Google ▸ Reconnaissance vocale hors ligne) ou écris ta commande."
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Autorise le micro pour JARVIS dans les paramètres."
                            else -> "Je n'ai pas compris, réessaie."
                        }
                    )
                }
                override fun onResults(results: Bundle?) {
                    onListeningChange(false)
                    val text = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                    if (!text.isNullOrBlank()) onResult(text)
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, !isOnline())
        }
        recognizer?.startListening(intent)
    }

    /** Hors ligne, on demande le pack vocal du téléphone ; en ligne, la reconnaissance standard (plus fiable). */
    private fun isOnline(): Boolean = try {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        cm.getNetworkCapabilities(cm.activeNetwork)?.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
    } catch (e: Exception) { true }

    fun stopListening() {
        recognizer?.stopListening()
    }

    fun speak(text: String) {
        if (!ttsReady) return
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_${System.currentTimeMillis()}")
    }

    /** Coupe immédiatement la voix en cours (commande "stop" / "tais-toi"). */
    fun stopSpeaking() {
        tts?.stop()
    }

    fun destroy() {
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
    }
}
