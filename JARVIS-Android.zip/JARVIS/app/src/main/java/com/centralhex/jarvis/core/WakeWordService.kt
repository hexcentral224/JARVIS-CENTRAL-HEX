package com.centralhex.jarvis.core

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.centralhex.jarvis.WakeActivity

/**
 * Écoute en permanence si on dit "JARVIS", même écran éteint — comme le
 * "Hey Siri"/"Dis Jarvis" des vrais assistants. Pour ça, Android exige un
 * service "au premier plan" avec une notification visible en continu : il
 * n'y a pas moyen d'écouter en arrière-plan sans que la personne le sache,
 * et c'est volontaire (ça protège la vie privée de tout le monde).
 *
 * Dès que le mot "JARVIS" est reconnu, ce service ouvre [WakeActivity] en
 * plein écran (par-dessus l'écran verrouillé si besoin, avec son animation) :
 * c'est elle qui écoute la commande et répond, pas ce service.
 *
 * ⚠️ Écouter en continu consomme de la batterie et certains téléphones
 * (Xiaomi, Huawei, Oppo...) coupent le micro en arrière-plan sauf si on
 * désactive l'optimisation de batterie pour JARVIS (voir le README).
 */
class WakeWordService : Service() {

    companion object {
        const val CHANNEL_ID = "jarvis_wakeword"
        const val WAKE_CHANNEL_ID = "jarvis_wake_fullscreen"
        const val NOTIF_ID = 42
        const val WAKE_NOTIF_ID = 43

        @Volatile var isRunning = false
            private set

        /** [WakeActivity] et l'écran Accueil mettent ceci à true pendant qu'ils utilisent le micro, pour ne pas se marcher dessus. */
        @Volatile var foregroundUiListening = false

        fun start(context: Context) {
            val intent = Intent(context, WakeWordService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent)
            else context.startService(intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, WakeWordService::class.java))
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        startForegroundNotification()
        handler.postDelayed({ listenCycle() }, 400)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    private fun startForegroundNotification() {
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "JARVIS à l'écoute", NotificationManager.IMPORTANCE_MIN)
            )
            manager.createNotificationChannel(
                NotificationChannel(WAKE_CHANNEL_ID, "JARVIS s'active", NotificationManager.IMPORTANCE_HIGH)
            )
        }
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.presence_audio_online)
            .setContentTitle("JARVIS veille")
            .setContentText("Dis « JARVIS » pour l'activer")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceCompat.startForeground(this, NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    /** Relance une courte écoute, en boucle, tant que le service tourne. */
    private fun listenCycle() {
        if (!isRunning) return
        if (foregroundUiListening) { handler.postDelayed({ listenCycle() }, 1200); return }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { handler.postDelayed({ listenCycle() }, 5000); return }

        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: android.os.Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) {
                    handler.postDelayed({ listenCycle() }, 600) // on réessaie, sans boucle trop rapide
                }
                override fun onResults(results: android.os.Bundle?) {
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    handleHeard(text)
                }
                override fun onPartialResults(partialResults: android.os.Bundle?) {}
                override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
            })
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 900)
        }
        try { recognizer?.startListening(intent) } catch (e: Exception) { handler.postDelayed({ listenCycle() }, 1500) }
    }

    private fun normalize(s: String) = s.lowercase()
        .replace("é", "e").replace("è", "e").replace("ê", "e").replace("à", "a")

    private fun handleHeard(rawText: String) {
        val text = normalize(rawText)
        if (!text.contains("jarvis")) { handler.postDelayed({ listenCycle() }, 300); return }

        // Réveil déclenché : on ouvre l'écran plein écran (il s'occupe de tout, animation comprise).
        launchWakeScreen()
        // Le service reprendra son écoute passive une fois que foregroundUiListening repassera à false.
        handler.postDelayed({ listenCycle() }, 1500)
    }

    /** Ouvre JARVIS en plein écran, même par-dessus l'écran verrouillé, avec son animation. */
    private fun launchWakeScreen() {
        val intent = Intent(this, WakeActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
        }
        val pending = PendingIntent.getActivity(
            this, 1, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Notification plein écran : c'est le mécanisme officiel Android pour réveiller l'écran
        // avec une vraie interface (le même que les appels entrants ou les alarmes).
        val notification = NotificationCompat.Builder(this, WAKE_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.presence_audio_online)
            .setContentTitle("JARVIS")
            .setContentText("Je vous écoute…")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setFullScreenIntent(pending, true)
            .setContentIntent(pending)
            .setAutoCancel(true)
            .build()

        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(WAKE_NOTIF_ID, notification)
        // Au cas où le plein écran est refusé par le système (permission non accordée) : on lance quand même l'activité.
        try { startActivity(intent) } catch (e: Exception) { /* la notification reste comme filet de secours */ }
    }

    override fun onDestroy() {
        isRunning = false
        recognizer?.destroy()
        super.onDestroy()
    }
}
