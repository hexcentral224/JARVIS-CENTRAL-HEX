package com.centralhex.jarvis.core

import android.app.KeyguardManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.centralhex.jarvis.WakeActivity
import com.centralhex.jarvis.data.ActivityEntry
import com.centralhex.jarvis.data.ChatMessage
import com.centralhex.jarvis.data.LocalStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Écoute en permanence si on dit "JARVIS", même écran éteint — comme le
 * "Hey Siri"/"Dis Jarvis" des vrais assistants. Pour ça, Android exige un
 * service "au premier plan" avec une notification visible en continu : il
 * n'y a pas moyen d'écouter en arrière-plan sans que la personne le sache,
 * et c'est volontaire (ça protège la vie privée de tout le monde).
 *
 * Dès que le mot "JARVIS" est reconnu, ce service ouvre [WakeActivity] en
 * plein écran (par-dessus l'écran verrouillé si besoin, avec son animation) :
 * c'est elle qui écoute la commande et répond, pas ce service.
 *
 * ⚠️ Écouter en continu consomme de la batterie et certains téléphones
 * (Xiaomi, Huawei, Oppo...) coupent le micro en arrière-plan sauf si on
 * désactive l'optimisation de batterie pour JARVIS (voir le README).
 */
class WakeWordService : Service() {

    companion object {
        const val CHANNEL_ID = "jarvis_wakeword"
        const val WAKE_CHANNEL_ID = "jarvis_wake_fullscreen"
        const val NOTIF_ID = 42
        const val WAKE_NOTIF_ID = 43

        @Volatile var isRunning = false
            private set

        /** [WakeActivity] et l'écran Accueil mettent ceci à true pendant qu'ils utilisent le micro, pour ne pas se marcher dessus. */
        @Volatile var foregroundUiListening = false

        fun start(context: Context) {
            val intent = Intent(context, WakeWordService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent)
            else context.startService(intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, WakeWordService::class.java))
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val ai = AiClient()
    private lateinit var store: LocalStore
    private lateinit var router: CommandRouter
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var onSpeechDone: (() -> Unit)? = null
    private var awaitingCommand = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        store = LocalStore(applicationContext)
        router = CommandRouter(DeviceActions(applicationContext), ReminderScheduler(applicationContext), store)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) { tts?.language = Locale.FRENCH; ttsReady = true }
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { handler.post { finishSpeech() } }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { handler.post { finishSpeech() } }
        })
        startForegroundNotification()
        handler.postDelayed({ listenCycle() }, 400)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    private fun startForegroundNotification() {
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "JARVIS à l'écoute", NotificationManager.IMPORTANCE_MIN)
            )
            manager.createNotificationChannel(
                NotificationChannel(WAKE_CHANNEL_ID, "JARVIS s'active", NotificationManager.IMPORTANCE_HIGH)
            )
        }
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.presence_audio_online)
            .setContentTitle("JARVIS veille")
            .setContentText("Dis « JARVIS » pour l'activer")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceCompat.startForeground(this, NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    /** Relance une courte écoute, en boucle, tant que le service tourne. */
    private fun listenCycle() {
        if (!isRunning) return
        if (foregroundUiListening) { handler.postDelayed({ listenCycle() }, 1200); return }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { handler.postDelayed({ listenCycle() }, 5000); return }

        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: android.os.Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) {
                    handler.postDelayed({ listenCycle() }, 600) // on réessaie, sans boucle trop rapide
                }
                override fun onResults(results: android.os.Bundle?) {
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    handleHeard(text)
                }
                override fun onPartialResults(partialResults: android.os.Bundle?) {}
                override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
            })
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, !isOnline())
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 900)
        }
        try { recognizer?.startListening(intent) } catch (e: Exception) { handler.postDelayed({ listenCycle() }, 1500) }
    }

    private fun isOnline(): Boolean = try {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        cm.getNetworkCapabilities(cm.activeNetwork)?.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
    } catch (e: Exception) { true }

    private fun normalize(s: String) = java.text.Normalizer.normalize(s.lowercase(), java.text.Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "").replace(Regex("[^a-z0-9 ]"), " ").replace(Regex("\\s+"), " ").trim()

    private fun distance(a: String, b: String): Int {
        val d = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) d[i][0] = i
        for (j in 0..b.length) d[0][j] = j
        for (i in 1..a.length) for (j in 1..b.length)
            d[i][j] = minOf(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
        return d[a.length][b.length]
    }

    private val wakeVariants = setOf("jarvis", "jarvice", "jarvisse", "gervais", "charvis", "djarvis", "jarwis", "zarvis", "garvis", "jarvi", "jarvy", "jarvise")

    /** Le micro comprend rarement "Jarvis" à la lettre : on accepte les prononciations proches. */
    private fun isWakeToken(t: String) = t in wakeVariants || (t.length >= 4 && distance(t, "jarvis") <= 2)

    private fun handleHeard(rawText: String) {
        if (awaitingCommand) {
            awaitingCommand = false
            if (rawText.isNotBlank()) handleCommand(rawText) else resumeListening(300)
            return
        }
        val tokens = normalize(rawText).split(" ").filter { it.isNotEmpty() }
        val idx = tokens.indexOfFirst { isWakeToken(it) }
        if (idx < 0) { resumeListening(300); return }

        val rest = tokens.drop(idx + 1).joinToString(" ")   // ex. « jarvis ouvre whatsapp » -> « ouvre whatsapp »

        if (shouldShowWakeScreen()) {
            launchWakeScreen(rest)
            resumeListening(1500)
            return
        }
        // Écran allumé (ou plein écran non autorisé) : JARVIS répond directement à la voix.
        if (rest.length > 2) handleCommand(rest)
        else {
            awaitingCommand = true
            speak("Oui ?") { listenCycle() }
        }
    }

    private fun resumeListening(delay: Long) { handler.postDelayed({ listenCycle() }, delay) }

    private fun handleCommand(text: String) {
        val s0 = store.load()
        val label = text.trim().replaceFirstChar { it.uppercase() }.take(48)
        store.save(
            s0.copy(
                history = s0.history + ChatMessage(fromUser = true, text = text),
                activityLog = (s0.activityLog + ActivityEntry(label = label)).takeLast(20)
            )
        )
        when (val result = router.route(text, store.load().rules)) {
            is RouteResult.LocalReply -> finishTurn(result.text)
            is RouteResult.StopSpeaking -> { tts?.stop(); resumeListening(500) }
            is RouteResult.AskAi -> scope.launch {
                val s = store.load()
                val res = ai.ask(s.history, s.settings)
                finishTurn(res.getOrElse { it.message ?: "Je n'ai pas pu répondre." })
            }
        }
    }

    private fun finishTurn(reply: String) {
        val s = store.load()
        store.save(s.copy(history = s.history + ChatMessage(fromUser = false, text = reply)))
        if (s.settings.autoSpeak) speak(reply) { listenCycle() } else resumeListening(700)
    }

    private fun speak(text: String, then: () -> Unit) {
        val t = tts
        if (t == null || !ttsReady) { handler.postDelayed({ then() }, 300); return }
        onSpeechDone = then
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_utt")
    }

    private fun finishSpeech() {
        val cb = onSpeechDone
        onSpeechDone = null
        // petite pause pour que le micro n'entende pas la fin de la voix de JARVIS
        handler.postDelayed({ cb?.invoke() }, 350)
    }

    /** L'écran de réveil animé n'a de sens que si l'écran est éteint/verrouillé ET que le plein écran est autorisé. */
    private fun shouldShowWakeScreen(): Boolean {
        val pm = getSystemService(PowerManager::class.java)
        val km = getSystemService(KeyguardManager::class.java)
        val screenOffOrLocked = !pm.isInteractive || km.isKeyguardLocked
        val fullScreenOk = Build.VERSION.SDK_INT < 34 ||
            getSystemService(NotificationManager::class.java).canUseFullScreenIntent()
        return screenOffOrLocked && fullScreenOk
    }

    /** Ouvre JARVIS en plein écran, même par-dessus l'écran verrouillé, avec son animation. */
    private fun launchWakeScreen(command: String) {
        val intent = Intent(this, WakeActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
            if (command.length > 2) putExtra("cmd", command)
        }
        val pending = PendingIntent.getActivity(
            this, 1, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(this, WAKE_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.presence_audio_online)
            .setContentTitle("JARVIS")
            .setContentText("Je vous écoute…")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setFullScreenIntent(pending, true)
            .setContentIntent(pending)
            .setAutoCancel(true)
            .build()
        getSystemService(NotificationManager::class.java).notify(WAKE_NOTIF_ID, notification)
        try { startActivity(intent) } catch (e: Exception) { /* la notification plein écran sert de secours */ }
    }

    override fun onDestroy() {
        isRunning = false
        scope.cancel()
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}
