package com.centralhex.jarvis.core

import android.app.KeyguardManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.centralhex.jarvis.WakeActivity
import com.centralhex.jarvis.data.ActivityEntry
import com.centralhex.jarvis.data.ChatMessage
import com.centralhex.jarvis.data.LocalStore
import com.centralhex.jarvis.ui.components.OrbState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Écoute en permanence si on dit "JARVIS", même écran éteint — comme le
 * "Hey Siri"/"Dis Jarvis" des vrais assistants. Pour ça, Android exige un
 * service "au premier plan" avec une notification visible en continu : il
 * n'y a pas moyen d'écouter en arrière-plan sans que la personne le sache,
 * et c'est volontaire (ça protège la vie privée de tout le monde).
 *
 * Dès que le mot "JARVIS" est reconnu, ce service ouvre [WakeActivity] en
 * plein écran (par-dessus l'écran verrouillé si besoin, avec son animation) :
 * c'est elle qui écoute la commande et répond, pas ce service.
 *
 * ⚠️ Écouter en continu consomme de la batterie et certains téléphones
 * (Xiaomi, Huawei, Oppo...) coupent le micro en arrière-plan sauf si on
 * désactive l'optimisation de batterie pour JARVIS (voir le README).
 */
class WakeWordService : Service() {

    companion object {
        const val CHANNEL_ID = "jarvis_wakeword"
        const val WAKE_CHANNEL_ID = "jarvis_wake_fullscreen"
        const val NOTIF_ID = 42
        const val WAKE_NOTIF_ID = 43

        @Volatile var isRunning = false
            private set

        @Volatile private var uiSince = 0L

        /**
         * [WakeActivity] et l'écran Accueil mettent ceci à true pendant qu'ils utilisent le micro, pour ne pas se
         * marcher dessus. Ça expire tout seul après 20 s : si l'appli oublie de le remettre à false, le service
         * ne reste pas bloqué pour toujours.
         */
        var foregroundUiListening: Boolean
            get() = uiSince > 0 && System.currentTimeMillis() - uiSince < 20_000
            set(value) { uiSince = if (value) System.currentTimeMillis() else 0L }

        @Volatile private var instance: WakeWordService? = null

        /** Vrai quand la reconnaissance hors ligne (Vosk) est chargée et écoute. */
        @Volatile var engineActive = false
            private set

        @Volatile private var appVisible = false

        /** Fait « ouvrir le micro » sans dire Jarvis (bouton micro, boule flottante, ouverture de l'appli). */
        fun activate(ack: String?): Boolean {
            val s = instance ?: return false
            s.handler.post { s.enterCommandMode(ack) }
            return true
        }

        fun setAppVisible(visible: Boolean) {
            appVisible = visible
            instance?.let { s -> s.handler.post { s.syncOverlay() } }
        }

        /** Appelé quand le modèle vocal vient d'être téléchargé. */
        fun onModelReady(context: Context) {
            val s = instance
            if (s != null) s.handler.post { s.loadVosk() }
            else if (LocalStore(context).load().settings.wakeWordEnabled) start(context)
        }

        fun start(context: Context) {
            val intent = Intent(context, WakeWordService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent)
            else context.startService(intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, WakeWordService::class.java))
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val ai = AiClient()
    private lateinit var store: LocalStore
    private lateinit var router: CommandRouter
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var onSpeechDone: (() -> Unit)? = null
    private var awaitingCommand = false
    private var vosk: VoskEngine? = null
    private var voskFailed = false
    private var overlay: OrbOverlay? = null
    private val awaitTimeout = Runnable {
        awaitingCommand = false
        setBus(OrbState.IDLE, "")
    }

    private fun setBus(state: OrbState, line: String) {
        JarvisBus.state.value = state
        JarvisBus.line.value = line
    }
    private var lastCycleAt = 0L
    private var generation = 0
    private val cycleRunnable = Runnable { listenCycle() }

    /** Planifie UN seul prochain cycle d'écoute : toute planification précédente est annulée. */
    private fun scheduleCycle(delay: Long) {
        handler.removeCallbacks(cycleRunnable)
        handler.postDelayed(cycleRunnable, delay)
    }

    private fun destroyRecognizer() {
        val r = recognizer
        recognizer = null
        generation++            // les callbacks tardifs de l'ancien micro seront ignorés
        try { r?.cancel() } catch (e: Exception) {}
        try { r?.destroy() } catch (e: Exception) {}
    }
    private var lastStatus = ""
    private var heardThisSession = false

    private val watchdog = object : Runnable {
        override fun run() {
            if (!isRunning) return
            syncOverlay()
            if (engineActive) { handler.postDelayed(this, 10_000); return }
            // Si la boucle d'écoute s'est arrêtée (voix bloquée, erreur silencieuse…), on la relance.
            if (System.currentTimeMillis() - lastCycleAt > 25_000 && !foregroundUiListening) {
                awaitingCommand = false
                destroyRecognizer()
                scheduleCycle(0)
            }
            handler.postDelayed(this, 10_000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        store = LocalStore(applicationContext)
        router = CommandRouter(DeviceActions(applicationContext), ReminderScheduler(applicationContext), store)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) { tts?.language = Locale.FRENCH; ttsReady = true }
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { handler.post { finishSpeech() } }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { handler.post { finishSpeech() } }
        })
        instance = this
        startForegroundNotification()
        scope.launch { JarvisBus.state.collect { overlay?.setState(it) } }
        loadVosk()
        syncOverlay()
        scheduleCycle(400)
        handler.postDelayed(watchdog, 10_000)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    private fun startForegroundNotification() {
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "JARVIS à l'écoute", NotificationManager.IMPORTANCE_MIN)
            )
            manager.createNotificationChannel(
                NotificationChannel(WAKE_CHANNEL_ID, "JARVIS s'active", NotificationManager.IMPORTANCE_HIGH)
            )
        }
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.presence_audio_online)
            .setContentTitle("JARVIS veille")
            .setContentText("Dis « JARVIS » pour l'activer")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceCompat.startForeground(this, NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    /** Relance une courte écoute, en boucle, tant que le service tourne. */
    private fun createRecognizer() {
        val myGen = ++generation
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: android.os.Bundle?) {
                    if (myGen == generation && !awaitingCommand) updateStatus("À l'écoute de « Jarvis »…")
                }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) {
                    if (myGen != generation || heardThisSession) return   // callback d'un ancien micro : on ignore
                    when (error) {
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT, SpeechRecognizer.ERROR_NO_MATCH -> scheduleCycle(250)
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> { try { recognizer?.cancel() } catch (e: Exception) {}; scheduleCycle(900) }
                        else -> {
                            // 11 = service vocal déconnecté, 5 = client… : on repart avec un micro tout neuf, sans se presser
                            updateStatus("Micro : erreur $error, nouvel essai…")
                            destroyRecognizer()
                            scheduleCycle(2500)
                        }
                    }
                }
                override fun onResults(results: android.os.Bundle?) {
                    if (myGen != generation || heardThisSession) return
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    handleHeard(text)
                }
                override fun onPartialResults(partialResults: android.os.Bundle?) {
                    // Dès qu'on entend « Jarvis » à moitié dit, on réagit sans attendre la fin de la phrase.
                    if (myGen != generation || awaitingCommand || heardThisSession) return
                    val text = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (normalize(text).split(" ").any { isWakeToken(it) }) {
                        heardThisSession = true
                        try { recognizer?.cancel() } catch (e: Exception) {}
                        handleHeard(text)
                    }
                }
                override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
            })
        }
    }

    private fun listenCycle() {
        if (!isRunning) return
        // Moteur hors ligne (Vosk) : il écoute déjà en continu, on le remet juste à l'écoute.
        if (vosk != null) {
            if (engineActive) { lastCycleAt = System.currentTimeMillis(); vosk?.resume() } else scheduleCycle(1000)
            return
        }
        if (foregroundUiListening) { scheduleCycle(1200); return }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { updateStatus("Reconnaissance vocale indisponible sur ce téléphone"); scheduleCycle(5000); return }

        lastCycleAt = System.currentTimeMillis()
        heardThisSession = false
        if (recognizer == null) createRecognizer()

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, !isOnline())
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 900)
        }
        try { recognizer?.startListening(intent) } catch (e: Exception) {
            destroyRecognizer(); scheduleCycle(2000)
        }
    }

    /** Met à jour le texte de la notification « JARVIS veille » : sert à voir ce que JARVIS entend. */
    private fun updateStatus(text: String) {
        if (text == lastStatus) return
        lastStatus = text
        val n = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.presence_audio_online)
            .setContentTitle("JARVIS veille")
            .setContentText(text)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setVisibility(NotificationCompat.VISIBILITY_SECRET) // rien d'affiché sur l'écran verrouillé
            .build()
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, n)
    }

    private fun isOnline(): Boolean = try {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        cm.getNetworkCapabilities(cm.activeNetwork)?.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
    } catch (e: Exception) { true }

    private fun normalize(s: String) = java.text.Normalizer.normalize(s.lowercase(), java.text.Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "").replace(Regex("[^a-z0-9 ]"), " ").replace(Regex("\\s+"), " ").trim()

    private fun distance(a: String, b: String): Int {
        val d = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) d[i][0] = i
        for (j in 0..b.length) d[0][j] = j
        for (i in 1..a.length) for (j in 1..b.length)
            d[i][j] = minOf(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
        return d[a.length][b.length]
    }

    private val wakeVariants = setOf("jarvis", "jarvice", "jarvisse", "gervais", "charvis", "djarvis", "jarwis", "zarvis", "garvis", "jarvi", "jarvy", "jarvise")

    /** Le micro comprend rarement "Jarvis" à la lettre : on accepte les prononciations proches. */
    private fun isWakeToken(t: String) = t in wakeVariants || (t.length >= 4 && distance(t, "jarvis") <= 2)

    private fun findWake(tokens: List<String>): Pair<Int, Int>? {
        for (i in tokens.indices) {
            if (isWakeToken(tokens[i])) return i to 1
            // « gare vis » → « garevis » : le micro coupe parfois le mot en deux
            if (i + 1 < tokens.size) {
                val joined = tokens[i] + tokens[i + 1]
                if (joined.length >= 5 && distance(joined, "jarvis") <= 2) return i to 2
            }
        }
        return null
    }

    /** Texte compris par le moteur hors ligne (une phrase complète à chaque fois). */
    private fun handleVoskText(text: String) {
        if (onSpeechDone != null) return        // JARVIS est en train de parler
        handleHeard(text)
    }

    private fun handleHeard(rawText: String) {
        val tokens = normalize(rawText).split(" ").filter { it.isNotEmpty() }
        val wake = findWake(tokens)

        if (awaitingCommand) {
            // On attendait la commande : si on entend seulement « Jarvis » à nouveau, on continue d'attendre.
            if (wake != null && tokens.size <= wake.first + wake.second) { handler.removeCallbacks(awaitTimeout); handler.postDelayed(awaitTimeout, 10_000); return }
            awaitingCommand = false
            handler.removeCallbacks(awaitTimeout)
            if (rawText.isNotBlank()) handleCommand(rawText) else { setBus(OrbState.IDLE, ""); resumeListening(300) }
            return
        }

        updateStatus(if (rawText.isBlank()) "Rien entendu" else "Entendu : « ${rawText.take(30)} »" + if (wake != null) " ✅" else "")
        if (wake == null) { resumeListening(300); return }

        val rest = tokens.drop(wake.first + wake.second).joinToString(" ")   // « jarvis ouvre whatsapp » -> « ouvre whatsapp »

        val showWakeScreen = shouldShowWakeScreen()
        if (showWakeScreen) launchWakeScreen(if (engineActive) "" else rest)
        if (showWakeScreen && !engineActive) { resumeListening(1500); return }   // ancien mode : l'écran de réveil écoute lui-même

        // Écran allumé, ou moteur hors ligne : JARVIS répond directement à la voix.
        if (rest.length > 2) handleCommand(rest) else enterCommandMode("Oui ?")
    }

    /** Ouvre le micro pour UNE commande (après « Jarvis », un toucher sur la boule, ou l'ouverture de l'appli). */
    private fun enterCommandMode(ack: String?) {
        awaitingCommand = true
        handler.removeCallbacks(awaitTimeout)
        setBus(OrbState.LISTENING, "Je vous écoute…")
        val begin = { scheduleCycle(0); handler.postDelayed(awaitTimeout, 10_000) }
        if (ack != null) speak(ack) { begin() } else begin()
    }

    private fun syncOverlay() {
        val want = isRunning && !appVisible && android.provider.Settings.canDrawOverlays(this) &&
            store.load().settings.floatingOrb
        if (want) {
            if (overlay == null) overlay = OrbOverlay(this) { enterCommandMode("Oui, je suis là.") }
            overlay?.show()
            overlay?.setState(JarvisBus.state.value)
        } else {
            overlay?.hide()
        }
    }

    private fun loadVosk() {
        if (vosk != null || voskFailed) return
        val dir = VoskModelStore.modelDir(this) ?: return
        updateStatus("Chargement de la voix hors ligne…")
        vosk = VoskEngine(
            modelDir = dir,
            onText = { handleVoskText(it) },
            onReady = {
                engineActive = true
                destroyRecognizer()                       // plus besoin du service vocal de Google
                updateStatus("À l'écoute de « Jarvis » (hors ligne)")
                scheduleCycle(0)
            },
            onFail = { msg ->
                updateStatus("Voix hors ligne indisponible : $msg")
                voskFailed = true
                engineActive = false
                vosk?.shutdown(); vosk = null
                scheduleCycle(1500)
            }
        ).also { it.start() }
    }

    private fun resumeListening(delay: Long) { scheduleCycle(delay) }

    private fun handleCommand(text: String) {
        val s0 = store.load()
        val label = text.trim().replaceFirstChar { it.uppercase() }.take(48)
        store.save(
            s0.copy(
                history = s0.history + ChatMessage(fromUser = true, text = text),
                activityLog = (s0.activityLog + ActivityEntry(label = label)).takeLast(20)
            )
        )
        when (val result = router.route(text, store.load().rules)) {
            is RouteResult.LocalReply -> finishTurn(result.text)
            is RouteResult.StopSpeaking -> { tts?.stop(); setBus(OrbState.IDLE, ""); resumeListening(500) }
            is RouteResult.AskAi -> scope.launch {
                setBus(OrbState.THINKING, "Analyse…")
                val s = store.load()
                val res = ai.ask(s.history, s.settings)
                finishTurn(res.getOrElse { it.message ?: "Je n'ai pas pu répondre." })
            }
        }
    }

    private fun finishTurn(reply: String) {
        val s = store.load()
        store.save(s.copy(history = s.history + ChatMessage(fromUser = false, text = reply)))
        updateStatus("JARVIS : ${reply.take(60)}")
        setBus(OrbState.SPEAKING, reply)
        if (s.settings.autoSpeak) speak(reply) { setBus(OrbState.IDLE, reply); scheduleCycle(0) }
        else { setBus(OrbState.IDLE, reply); resumeListening(700) }
    }

    private fun speak(text: String, then: () -> Unit) {
        vosk?.pause()
        val t = tts
        if (t == null || !ttsReady) { handler.postDelayed({ then() }, 300); return }
        onSpeechDone = then
        val result = t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_utt")
        if (result == TextToSpeech.ERROR) { handler.post { finishSpeech() }; return }
        // Filet de sécurité : si la voix ne dit jamais « j'ai fini » (voix française absente…), on repart quand même.
        handler.postDelayed({ if (onSpeechDone != null) finishSpeech() }, 4000L + text.length * 90L)
    }

    private fun finishSpeech() {
        val cb = onSpeechDone
        onSpeechDone = null
        // petite pause pour que le micro n'entende pas la fin de la voix de JARVIS
        handler.postDelayed({ cb?.invoke() }, 350)
    }

    /** L'écran de réveil animé n'a de sens que si l'écran est éteint/verrouillé ET que le plein écran est autorisé. */
    private fun shouldShowWakeScreen(): Boolean {
        val pm = getSystemService(PowerManager::class.java)
        val km = getSystemService(KeyguardManager::class.java)
        val screenOffOrLocked = !pm.isInteractive || km.isKeyguardLocked
        val fullScreenOk = Build.VERSION.SDK_INT < 34 ||
            getSystemService(NotificationManager::class.java).canUseFullScreenIntent()
        return screenOffOrLocked && fullScreenOk
    }

    /** Ouvre JARVIS en plein écran, même par-dessus l'écran verrouillé, avec son animation. */
    private fun launchWakeScreen(command: String) {
        val intent = Intent(this, WakeActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
            if (command.length > 2) putExtra("cmd", command)
        }
        val pending = PendingIntent.getActivity(
            this, 1, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(this, WAKE_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.presence_audio_online)
            .setContentTitle("JARVIS")
            .setContentText("Je vous écoute…")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setFullScreenIntent(pending, true)
            .setContentIntent(pending)
            .setAutoCancel(true)
            .build()
        getSystemService(NotificationManager::class.java).notify(WAKE_NOTIF_ID, notification)
        try { startActivity(intent) } catch (e: Exception) { /* la notification plein écran sert de secours */ }
    }

    override fun onDestroy() {
        isRunning = false
        instance = null
        engineActive = false
        setBus(OrbState.IDLE, "")
        overlay?.hide()
        vosk?.shutdown()
        scope.cancel()
        handler.removeCallbacksAndMessages(null)
        destroyRecognizer()
        tts?.shutdown()
        super.onDestroy()
    }
}
