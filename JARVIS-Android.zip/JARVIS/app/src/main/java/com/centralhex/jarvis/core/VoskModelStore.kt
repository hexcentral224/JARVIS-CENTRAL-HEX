package com.centralhex.jarvis.core

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/** Télécharge (une seule fois, ~41 Mo) le modèle français qui permet de comprendre la voix sans internet. */
object VoskModelStore {

    sealed class State {
        object Unknown : State()
        object Missing : State()
        data class Downloading(val percent: Int) : State()
        object Installed : State()
        data class Failed(val reason: String) : State()
    }

    private const val MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-fr-0.22.zip"

    val state = MutableStateFlow<State>(State.Unknown)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private fun root(ctx: Context) = File(ctx.filesDir, "vosk-fr")

    /** Dossier du modèle prêt à l'emploi (celui qui contient "am" et "conf"), ou null. */
    fun modelDir(ctx: Context): File? {
        val r = root(ctx)
        if (File(r, "am").exists()) return r
        return r.listFiles()?.firstOrNull { it.isDirectory && File(it, "am").exists() }
    }

    fun refresh(ctx: Context) {
        if (state.value is State.Downloading) return
        state.value = if (modelDir(ctx) != null) State.Installed else State.Missing
    }

    fun download(ctx: Context) {
        if (state.value is State.Downloading) return
        val app = ctx.applicationContext
        state.value = State.Downloading(0)
        scope.launch {
            try {
                val zip = File(app.cacheDir, "vosk-fr.zip")
                val conn = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 20_000; readTimeout = 30_000; instanceFollowRedirects = true
                }
                val total = conn.contentLengthLong.coerceAtLeast(1L)
                conn.inputStream.use { input ->
                    FileOutputStream(zip).use { out ->
                        val buf = ByteArray(64 * 1024)
                        var done = 0L
                        var lastPct = -1
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            val pct = (done * 90 / total).toInt()          // 0-90 % : téléchargement
                            if (pct != lastPct) { lastPct = pct; state.value = State.Downloading(pct) }
                        }
                    }
                }
                state.value = State.Downloading(92)                          // 92-99 % : décompression
                val target = root(app)
                target.deleteRecursively(); target.mkdirs()
                val canonicalRoot = target.canonicalPath
                ZipInputStream(zip.inputStream().buffered()).use { zin ->
                    while (true) {
                        val e = zin.nextEntry ?: break
                        val f = File(target, e.name)
                        if (!f.canonicalPath.startsWith(canonicalRoot)) continue   // sécurité : pas de sortie du dossier
                        if (e.isDirectory) f.mkdirs()
                        else { f.parentFile?.mkdirs(); FileOutputStream(f).use { zin.copyTo(it) } }
                    }
                }
                zip.delete()
                if (modelDir(app) == null) throw IllegalStateException("modèle incomplet")
                state.value = State.Installed
                WakeWordService.onModelReady(app)
            } catch (e: Exception) {
                state.value = State.Failed(e.message ?: "erreur de téléchargement")
            }
        }
    }
}
