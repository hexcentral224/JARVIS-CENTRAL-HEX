package com.centralhex.jarvis.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.centralhex.jarvis.ui.theme.HudBg
import com.centralhex.jarvis.ui.theme.HudCyan
import com.centralhex.jarvis.ui.theme.HudGold
import com.centralhex.jarvis.ui.theme.HudGreen
import com.centralhex.jarvis.ui.theme.HudPanel
import com.centralhex.jarvis.ui.theme.HudRed
import com.centralhex.jarvis.ui.theme.HudText
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

fun orbColor(state: OrbState): Color = when (state) {
    OrbState.IDLE -> HudCyan
    OrbState.LISTENING -> HudRed
    OrbState.THINKING -> HudGold
    OrbState.SPEAKING -> HudGreen
}

/** Fond d'écran HUD : quadrillage discret et un balayage lumineux qui descend lentement. */
@Composable
fun HudBackground(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val t = rememberInfiniteTransition(label = "bg")
    val scan by t.animateFloat(0f, 1f, infiniteRepeatable(tween(7000, easing = LinearEasing)), label = "scan")
    Box(modifier.background(HudBg)) {
        Canvas(Modifier.fillMaxSize()) {
            val step = 44.dp.toPx()
            val line = HudCyan.copy(alpha = 0.045f)
            var x = 0f
            while (x < this.size.width) { drawLine(line, Offset(x, 0f), Offset(x, this.size.height), 1f); x += step }
            var y = 0f
            while (y < this.size.height) { drawLine(line, Offset(0f, y), Offset(this.size.width, y), 1f); y += step }
            val sy = this.size.height * scan
            drawRect(
                Brush.verticalGradient(
                    listOf(Color.Transparent, HudCyan.copy(alpha = 0.10f), Color.Transparent),
                    startY = sy - 120f, endY = sy + 120f
                ),
                topLeft = Offset(0f, sy - 120f), size = Size(this.size.width, 240f)
            )
        }
        content()
    }
}

/** Panneau « verre » avec fine bordure et coins lumineux, comme un affichage de casque. */
fun Modifier.hudPanel(accent: Color = HudCyan): Modifier = this.drawBehind {
    drawRect(HudPanel.copy(alpha = 0.78f))
    drawRect(accent.copy(alpha = 0.22f), style = Stroke(1.dp.toPx()))
    val l = 14.dp.toPx()
    val w = 2.dp.toPx()
    val sw = this.size.width
    val sh = this.size.height
    drawLine(accent, Offset(0f, 0f), Offset(l, 0f), w); drawLine(accent, Offset(0f, 0f), Offset(0f, l), w)
    drawLine(accent, Offset(sw, 0f), Offset(sw - l, 0f), w); drawLine(accent, Offset(sw, 0f), Offset(sw, l), w)
    drawLine(accent, Offset(0f, sh), Offset(l, sh), w); drawLine(accent, Offset(0f, sh), Offset(0f, sh - l), w)
    drawLine(accent, Offset(sw, sh), Offset(sw - l, sh), w); drawLine(accent, Offset(sw, sh), Offset(sw, sh - l), w)
}

/**
 * Le « réacteur » de JARVIS : anneaux qui tournent, graduations, hexagone central et barres de voix.
 * Calme au repos, rapide et coloré quand il écoute, réfléchit ou parle.
 */
@Composable
fun ArcReactor(state: OrbState, diameter: Dp, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "reactor")
    val active = state != OrbState.IDLE
    val rot by t.animateFloat(0f, 360f, infiniteRepeatable(tween(if (active) 3500 else 9000, easing = LinearEasing)), label = "rot")
    val rot2 by t.animateFloat(360f, 0f, infiniteRepeatable(tween(if (active) 5200 else 14000, easing = LinearEasing)), label = "rot2")
    val pulse by t.animateFloat(
        0.88f, 1f,
        infiniteRepeatable(tween(if (active) 500 else 1600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse"
    )
    val phase by t.animateFloat(0f, 6.2832f, infiniteRepeatable(tween(1200, easing = LinearEasing)), label = "phase")
    val c = orbColor(state)

    Canvas(modifier.size(diameter)) {
        val cx = this.size.width / 2f
        val cy = this.size.height / 2f
        val center = Offset(cx, cy)
        val big = this.size.minDimension / 2f

        // lueur
        drawCircle(
            Brush.radialGradient(listOf(c.copy(alpha = 0.32f * pulse), Color.Transparent), center = center, radius = big),
            radius = big, center = center
        )
        // anneau extérieur fin
        drawCircle(c.copy(alpha = 0.35f), radius = big * 0.98f, center = center, style = Stroke(1.5f))

        // trois arcs épais qui tournent
        val ra = big * 0.9f
        rotate(rot, center) {
            for (i in 0 until 3) {
                drawArc(
                    c, startAngle = i * 120f, sweepAngle = 70f, useCenter = false,
                    topLeft = Offset(cx - ra, cy - ra), size = Size(ra * 2, ra * 2),
                    style = Stroke(width = 5f, cap = StrokeCap.Round)
                )
            }
        }

        // graduations (60 traits) qui tournent en sens inverse
        rotate(rot2, center) {
            for (i in 0 until 60) {
                val a = Math.toRadians(i * 6.0)
                val major = i % 5 == 0
                val outer = big * 0.82f
                val inner = outer - big * (if (major) 0.07f else 0.035f)
                drawLine(
                    if (major) c else Color.White.copy(alpha = 0.3f),
                    Offset(cx + inner * cos(a).toFloat(), cy + inner * sin(a).toFloat()),
                    Offset(cx + outer * cos(a).toFloat(), cy + outer * sin(a).toFloat()),
                    strokeWidth = if (major) 2.5f else 1.2f
                )
            }
        }

        // anneau en pointillés
        rotate(-rot, center) {
            drawCircle(
                c.copy(alpha = 0.55f), radius = big * 0.66f, center = center,
                style = Stroke(2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f)))
            )
        }

        // barres de voix autour du cœur
        val bars = 40
        for (i in 0 until bars) {
            val a = Math.toRadians(i * 360.0 / bars)
            val amp = if (active) 0.35f + 0.65f * abs(sin(phase + i * 0.7f)) else 0.15f + 0.1f * abs(sin(phase + i * 0.3f))
            val inner = big * 0.5f
            val outer = inner + big * 0.11f * amp * (if (state == OrbState.LISTENING) 1.5f else 1f)
            drawLine(
                c.copy(alpha = if (active) 0.9f else 0.35f),
                Offset(cx + inner * cos(a).toFloat(), cy + inner * sin(a).toFloat()),
                Offset(cx + outer * cos(a).toFloat(), cy + outer * sin(a).toFloat()),
                strokeWidth = 3f, cap = StrokeCap.Round
            )
        }

        // hexagone central
        rotate(rot * 1.5f, center) {
            val hr = big * 0.34f * pulse
            for (i in 0 until 6) {
                val a1 = Math.toRadians(i * 60.0)
                val a2 = Math.toRadians((i + 1) * 60.0)
                drawLine(
                    c,
                    Offset(cx + hr * cos(a1).toFloat(), cy + hr * sin(a1).toFloat()),
                    Offset(cx + hr * cos(a2).toFloat(), cy + hr * sin(a2).toFloat()),
                    strokeWidth = 4f, cap = StrokeCap.Round
                )
            }
        }
        // cœur lumineux
        drawCircle(
            Brush.radialGradient(listOf(Color.White.copy(alpha = 0.95f), c.copy(alpha = 0.85f), Color.Transparent), center = center, radius = big * 0.26f * pulse),
            radius = big * 0.26f * pulse, center = center
        )
    }
}

/** Jauge circulaire (batterie, etc.) avec le chiffre au centre. */
@Composable
fun RingGauge(fraction: Float, label: String, color: Color, diameter: Dp = 66.dp) {
    val f by animateFloatAsState(fraction.coerceIn(0f, 1f), tween(800), label = "gauge")
    Box(Modifier.size(diameter), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(diameter)) {
            val stroke = 6.dp.toPx()
            val inset = stroke / 2
            drawArc(
                color.copy(alpha = 0.18f), -90f, 360f, false,
                topLeft = Offset(inset, inset), size = Size(this.size.width - stroke, this.size.height - stroke),
                style = Stroke(stroke)
            )
            drawArc(
                color, -90f, 360f * f, false,
                topLeft = Offset(inset, inset), size = Size(this.size.width - stroke, this.size.height - stroke),
                style = Stroke(stroke, cap = StrokeCap.Round)
            )
        }
        Text(label, color = HudText, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
    }
}
