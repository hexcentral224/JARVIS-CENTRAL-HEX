package com.centralhex.jarvis.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val JarvisTypography = Typography(
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 22.sp),
    bodySmall = TextStyle(fontSize = 13.sp, lineHeight = 18.sp),
    titleLarge = TextStyle(fontSize = 22.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp),
    titleMedium = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 2.sp),
    labelSmall = TextStyle(fontSize = 10.sp, fontFamily = FontFamily.Monospace, letterSpacing = 1.2.sp),
    labelMedium = TextStyle(fontSize = 11.sp, fontFamily = FontFamily.Monospace, letterSpacing = 1.sp)
)
