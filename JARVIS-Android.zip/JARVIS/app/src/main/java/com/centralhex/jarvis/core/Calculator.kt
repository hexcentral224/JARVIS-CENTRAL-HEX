package com.centralhex.jarvis.core

/**
 * Calcul simple, 100 % hors ligne : "12 fois 15", "20 + 5", "100 divisé par 4".
 * Volontairement limité à une seule opération pour rester fiable sans dépendance.
 */
object Calculator {
    private val words = mapOf(
        "plus" to "+", "et" to "+",
        "moins" to "-",
        "fois" to "*", "multiplie par" to "*", "multiplié par" to "*",
        "divise par" to "/", "divisé par" to "/", "sur" to "/"
    )

    private val exprRx = Regex("""(-?\d+(?:[.,]\d+)?)\s*([+\-*/])\s*(-?\d+(?:[.,]\d+)?)""")

    fun evaluate(rawText: String): String? {
        var text = rawText.lowercase()
        for ((word, symbol) in words.toList().sortedByDescending { it.first.length }) {
            text = text.replace(word, " $symbol ")
        }
        text = text.replace(',', '.')

        val m = exprRx.find(text) ?: return null
        val a = m.groupValues[1].toDoubleOrNull() ?: return null
        val op = m.groupValues[2]
        val b = m.groupValues[3].toDoubleOrNull() ?: return null

        val result = when (op) {
            "+" -> a + b
            "-" -> a - b
            "*" -> a * b
            "/" -> if (b == 0.0) return "Impossible de diviser par zéro." else a / b
            else -> return null
        }
        val clean = if (result == result.toLong().toDouble()) result.toLong().toString()
        else String.format("%.2f", result)
        return "Le résultat est $clean."
    }
}
