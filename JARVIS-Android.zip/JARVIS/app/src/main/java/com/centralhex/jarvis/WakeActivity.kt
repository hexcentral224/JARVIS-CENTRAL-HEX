package com.centralhex.jarvis

import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.centralhex.jarvis.core.*
import com.centralhex.jarvis.data.ActivityEntry
import com.centralhex.jarvis.data.ChatMessage
import com.centralhex.jarvis.data.LocalStore
import com.centralhex.jarvis.ui.components.HexOrb
import com.centralhex.jarvis.ui.components.OrbState
import com.centralhex.jarvis.ui.theme.HexBg
import com.centralhex.jarvis.ui.theme.HexMuted
import com.centralhex.jarvis.ui.theme.JarvisTheme
import kotlinx.coroutines.launch

/**
 * S'ouvre PAR-DESSUS l'écran verrouillé quand JARVIS entend son nom, avec une
 * vraie animation d'hexagone (pas juste une notification) — exactement le
 * "il s'allume comme un robot" demandé. Le téléphone reste verrouillé :
 * cet écran se contente de s'afficher par-dessus, il ne déverrouille rien.
 */
class WakeActivity : ComponentActivity() {

    private lateinit var store: LocalStore
    private lateinit var router: CommandRouter
    private val ai = AiClient()
    private var voice: VoiceManager? = null
    private val handler = Handler(Looper.getMainLooper())

    private var orbState by mutableStateOf(OrbState.LISTENING)
    private var statusText by mutableStateOf("Je vous écoute…")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showOverLockScreen()
        WakeWordService.foregroundUiListening = true

        store = LocalStore(applicationContext)
        val device = DeviceActions(applicationContext)
        router = CommandRouter(device, ReminderScheduler(applicationContext), store)
        voice = VoiceManager(
            context = this,
            onResult = { text -> handleCommand(text) },
            onListeningChange = { listening -> if (listening) orbState = OrbState.LISTENING },
            onError = { statusText = it; scheduleClose(3500) }
        )

        setContent {
            JarvisTheme(dark = true) { WakeScreen() }
        }

        val cmd = intent.getStringExtra("cmd")
        if (!cmd.isNullOrBlank()) handleCommand(cmd) else voice?.startListening()
        scheduleClose(15000) // filet de sécurité : se referme seul si rien ne se passe
    }

    private fun showOverLockScreen() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            )
        }
    }

    private fun handleCommand(text: String) {
        handler.removeCallbacksAndMessages(null)
        val s0 = store.load()
        val label = text.trim().replaceFirstChar { it.uppercase() }.take(48)
        store.save(
            s0.copy(
                history = s0.history + ChatMessage(fromUser = true, text = text),
                activityLog = (s0.activityLog + ActivityEntry(label = label)).takeLast(20)
            )
        )

        when (val result = router.route(text, store.load().rules)) {
            is RouteResult.LocalReply -> respondAndClose(result.text)
            is RouteResult.StopSpeaking -> { voice?.stopSpeaking(); scheduleClose(600) }
            is RouteResult.AskAi -> {
                orbState = OrbState.THINKING
                statusText = "Je réfléchis…"
                lifecycleScope.launch {
                    val s = store.load()
                    val res = ai.ask(s.history, s.settings)
                    respondAndClose(res.getOrElse { it.message ?: "Je n'ai pas pu répondre." })
                }
            }
        }
    }

    private fun respondAndClose(reply: String) {
        val s = store.load()
        store.save(s.copy(history = s.history + ChatMessage(fromUser = false, text = reply)))
        orbState = OrbState.SPEAKING
        statusText = reply
        if (s.settings.autoSpeak) voice?.speak(reply)
        scheduleClose(5500)
    }

    private fun scheduleClose(delay: Long) {
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ finishAndRemoveTask() }, delay)
    }

    @Composable
    private fun WakeScreen() {
        Scaffold(containerColor = HexBg) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                HexOrb(orbState, 180.dp, Color.White)
                Spacer(Modifier.height(28.dp))
                Text("JARVIS", color = Color.White, fontSize = 22.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, letterSpacing = 2.sp)
                Spacer(Modifier.height(10.dp))
                Text(statusText, color = HexMuted, fontSize = 15.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                Spacer(Modifier.height(40.dp))
                FilledIconButton(
                    onClick = { orbState = OrbState.LISTENING; statusText = "Je vous écoute…"; voice?.startListening(); scheduleClose(15000) },
                    modifier = Modifier.size(64.dp)
                ) { Icon(Icons.Filled.Mic, contentDescription = "Reparler", modifier = Modifier.size(28.dp)) }
                Spacer(Modifier.height(18.dp))
                Image(
                    painterResource(R.drawable.jarvis_logo), contentDescription = "CENTRAL-HEX",
                    modifier = Modifier.size(52.dp).clip(CircleShape)
                )
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        voice?.destroy()
        WakeWordService.foregroundUiListening = false
    }
}
