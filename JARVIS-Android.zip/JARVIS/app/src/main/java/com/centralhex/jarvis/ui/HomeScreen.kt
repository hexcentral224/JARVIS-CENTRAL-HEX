package com.centralhex.jarvis.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.size
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import com.centralhex.jarvis.R
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.centralhex.jarvis.core.DeviceActions
import com.centralhex.jarvis.data.ActivityEntry
import com.centralhex.jarvis.data.ChatMessage
import com.centralhex.jarvis.ui.components.HexOrb
import com.centralhex.jarvis.ui.components.OrbState
import com.centralhex.jarvis.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class QuickAction(val icon: androidx.compose.ui.graphics.vector.ImageVector, val label: String, val sub: String, val run: () -> Unit)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(viewModel: JarvisViewModel, onOpenRules: () -> Unit, onOpenSettings: () -> Unit) {
    val state by viewModel.state.collectAsState()
    val isThinking by viewModel.isThinking.collectAsState()
    val isListening by viewModel.isListening.collectAsState()
    var input by remember { mutableStateOf("") }

    val context = androidx.compose.ui.platform.LocalContext.current
    val device = remember { DeviceActions(context) }
    var battery by remember { mutableStateOf(device.batteryInfo()) }
    var wifi by remember { mutableStateOf(device.isWifiConnected()) }
    var mobile by remember { mutableStateOf(device.isMobileDataConnected()) }

    LaunchedEffect(Unit) {
        while (true) {
            viewModel.refreshFromDisk()
            battery = device.batteryInfo(); wifi = device.isWifiConnected(); mobile = device.isMobileDataConnected()
            kotlinx.coroutines.delay(2000)
        }
    }

    fun send(text: String) { if (text.isNotBlank()) { viewModel.sendMessage(text); input = "" } }
    fun fill(prefix: String) { input = prefix }

    val actions = listOf(
        QuickAction(Icons.Filled.Chat, "Chat IA", "Pose tes questions") {},
        QuickAction(Icons.Filled.Mic, "Voix", "Parle avec JARVIS") { viewModel.toggleListening() },
        QuickAction(Icons.Filled.Apps, "Applications", "ouvre ") { fill("ouvre ") },
        QuickAction(Icons.Filled.Call, "Appels & SMS", "appelle ") { fill("appelle ") },
        QuickAction(Icons.Filled.Alarm, "Alarmes", "règle une alarme à ") { fill("règle une alarme à ") },
        QuickAction(Icons.Filled.Settings, "Automatisations", "Règles intelligentes") { onOpenRules() }
    )

    Scaffold(
        topBar = { HomeTopBar(wifi, mobile, battery, onOpenSettings) },
        bottomBar = {
            InputBar(input, { input = it }, isListening, { viewModel.toggleListening() }, { send(input) })
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding).padding(horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(vertical = 14.dp)
        ) {
            item { HeroCard(isListening, isThinking, !wifi && !mobile, state.history.lastOrNull { !it.fromUser }?.text) }

            item {
                Text("Actions rapides", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            }
            item {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    modifier = Modifier.heightIn(max = 220.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(actions) { a -> QuickActionTile(a) }
                }
            }

            item { SystemStatusCard(battery, wifi, mobile) }

            item {
                Text("Chat avec JARVIS", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            }
            items(state.history.takeLast(6), key = { it.id }) { msg -> Bubble(msg) }
            if (isThinking) item { ThinkingBubble() }

            item { ActivityCard(state.activityLog) }
            item { QuickTogglesRow(viewModel, state.settings) }
            item {
                Text(
                    "CENTRAL-HEX · Plus qu'un assistant, un partenaire.",
                    style = MaterialTheme.typography.labelSmall,
                    color = HexMuted,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HomeTopBar(wifi: Boolean, mobile: Boolean, battery: DeviceActions.Battery, onOpenSettings: () -> Unit) {
    TopAppBar(
        title = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painterResource(R.drawable.jarvis_logo), contentDescription = "JARVIS",
                        modifier = Modifier.size(34.dp).clip(CircleShape)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text("CENTRAL-HEX", fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                }
                Text("JARVIS · ASSISTANT IA", style = MaterialTheme.typography.labelSmall, color = HexMuted)
            }
        },
        actions = {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(end = 10.dp)) {
                Icon(
                    if (wifi) Icons.Filled.Wifi else if (mobile) Icons.Filled.SignalCellular4Bar else Icons.Filled.WifiOff,
                    contentDescription = null, tint = HexMuted, modifier = Modifier.size(16.dp)
                )
                Spacer(Modifier.width(8.dp))
                Text("${battery.percent}%", style = MaterialTheme.typography.labelSmall, color = HexMuted)
                Spacer(Modifier.width(12.dp))
                IconButton(onClick = onOpenSettings) { Icon(Icons.Filled.Settings, contentDescription = "Réglages") }
            }
        }
    )
}

@Composable
private fun HeroCard(isListening: Boolean, isThinking: Boolean, offline: Boolean, lastAiText: String?) {
    val orbState = if (isListening) OrbState.LISTENING else if (isThinking) OrbState.THINKING else OrbState.IDLE
    Box(
        Modifier.fillMaxWidth()
            .background(HexCard, RoundedCornerShape(20.dp))
            .padding(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            HexOrb(orbState, 72.dp, MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("CENTRAL-HEX", style = MaterialTheme.typography.labelSmall, color = HexMuted, letterSpacing = 1.sp)
                Text("JARVIS", fontWeight = FontWeight.Bold, fontSize = 22.sp)
                Text(
                    if (isListening) "À l'écoute…" else if (isThinking) "Réflexion…" else if (offline) "Hors connexion · commandes du téléphone actives" else "Assistant IA à votre service",
                    style = MaterialTheme.typography.labelSmall, color = HexMuted
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        Box(
            Modifier.fillMaxWidth()
                .background(HexBubbleAi, RoundedCornerShape(14.dp))
                .padding(12.dp)
        ) {
            Text(
                lastAiText ?: "Salut ! Je suis JARVIS. Dis-moi ce dont tu as besoin.",
                color = Color.White, style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun QuickActionTile(a: QuickAction) {
    Column(
        Modifier
            .background(HexCard, RoundedCornerShape(14.dp))
            .padding(vertical = 14.dp, horizontal = 6.dp)
            .fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        IconButton(onClick = a.run) {
            Icon(a.icon, contentDescription = a.label, tint = MaterialTheme.colorScheme.primary)
        }
        Text(a.label, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Medium, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
    }
}

@Composable
private fun SystemStatusCard(battery: DeviceActions.Battery, wifi: Boolean, mobile: Boolean) {
    Column(Modifier.fillMaxWidth().background(HexCard, RoundedCornerShape(18.dp)).padding(16.dp)) {
        Text("État du système", fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(10.dp))
        StatusRow("Batterie", "${battery.percent} %" + if (battery.charging) " · en charge" else "", battery.charging || battery.percent > 20)
        StatusRow("Wi-Fi", if (wifi) "Connecté" else "Non connecté", wifi)
        StatusRow("Données mobiles", if (mobile) "Connecté" else "Non connecté", mobile)
    }
}

@Composable
private fun StatusRow(label: String, value: String, ok: Boolean) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = HexMuted, style = MaterialTheme.typography.bodySmall)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(7.dp).background(if (ok) HexGreen else HexMuted, CircleShape))
            Spacer(Modifier.width(6.dp))
            Text(value, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun ActivityCard(log: List<ActivityEntry>) {
    val fmt = remember { SimpleDateFormat("HH:mm", Locale.FRENCH) }
    Column(Modifier.fillMaxWidth().background(HexCard, RoundedCornerShape(18.dp)).padding(16.dp)) {
        Text("Dernières activités", fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        if (log.isEmpty()) {
            Text("Rien pour le moment.", color = HexMuted, style = MaterialTheme.typography.bodySmall)
        } else {
            log.takeLast(6).reversed().forEach { entry ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 5.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(entry.label, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                    Text(fmt.format(Date(entry.id)), style = MaterialTheme.typography.labelSmall, color = HexMuted)
                }
            }
        }
    }
}

@Composable
private fun QuickTogglesRow(viewModel: JarvisViewModel, settings: com.centralhex.jarvis.data.JarvisSettings) {
    Row(
        Modifier.fillMaxWidth().background(HexCard, RoundedCornerShape(18.dp)).padding(14.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        ToggleChip("Mot « JARVIS »", settings.wakeWordEnabled) { viewModel.updateSettings(settings.copy(wakeWordEnabled = it)) }
        ToggleChip("Voix", settings.autoSpeak) { viewModel.updateSettings(settings.copy(autoSpeak = it)) }
        ToggleChip("Sombre", settings.darkTheme) { viewModel.updateSettings(settings.copy(darkTheme = it)) }
    }
}

@Composable
private fun ToggleChip(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = HexMuted)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

// ── Composants de chat réutilisés par l'accueil et, plus tard, par l'écran de réveil ──

@Composable
internal fun Bubble(message: ChatMessage) {
    val align = if (message.fromUser) Alignment.CenterEnd else Alignment.CenterStart
    val bg = if (message.fromUser) HexBubbleUser else HexBubbleAi
    Box(Modifier.fillMaxWidth(), contentAlignment = align) {
        Box(
            Modifier.widthIn(max = 280.dp).background(bg, RoundedCornerShape(14.dp)).padding(horizontal = 12.dp, vertical = 9.dp)
        ) { Text(message.text, color = Color.White, style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable
internal fun ThinkingBubble() {
    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterStart) {
        Box(Modifier.background(HexBubbleAi, RoundedCornerShape(14.dp)).padding(horizontal = 12.dp, vertical = 9.dp)) {
            Text("JARVIS réfléchit…", color = HexMuted, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
internal fun InputBar(
    input: String, onInputChange: (String) -> Unit, isListening: Boolean,
    onMicClick: () -> Unit, onSend: () -> Unit
) {
    Surface(color = HexSurface, tonalElevation = 0.dp) {
        Row(
            Modifier.fillMaxWidth().padding(10.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = input, onValueChange = onInputChange, modifier = Modifier.weight(1f),
                placeholder = { Text("Écris ta commande…") }, shape = RoundedCornerShape(20.dp), maxLines = 4,
                leadingIcon = { Icon(Icons.Filled.Mic, contentDescription = null, tint = HexMuted) }
            )
            FilledIconButton(
                onClick = onMicClick,
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = if (isListening) HexRed else HexWhite)
            ) { Icon(if (isListening) Icons.Filled.MicOff else Icons.Filled.Mic, contentDescription = "Micro", tint = HexBg) }
            FilledIconButton(onClick = onSend, colors = IconButtonDefaults.filledIconButtonColors(containerColor = HexGreen)) {
                Icon(Icons.Filled.Send, contentDescription = "Envoyer", tint = HexBg)
            }
        }
    }
}
