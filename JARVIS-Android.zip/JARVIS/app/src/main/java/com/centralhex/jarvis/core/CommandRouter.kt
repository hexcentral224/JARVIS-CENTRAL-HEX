package com.centralhex.jarvis.core

import com.centralhex.jarvis.data.AutomationRule
import com.centralhex.jarvis.data.LocalStore
import com.centralhex.jarvis.data.Note

sealed class RouteResult {
    data class LocalReply(val text: String) : RouteResult()   // traité sur le téléphone, réponse immédiate
    data class AskAi(val text: String) : RouteResult()        // aucune commande reconnue : on demande à l'IA
    object StopSpeaking : RouteResult()                       // "stop" / "tais-toi" : couper la voix, sans réponse parlée
}

/**
 * Comprend les phrases simples en français avant d'appeler l'IA.
 * Ça rend JARVIS rapide et fiable pour les actions courantes, même sans
 * connexion internet ou sans clé IA configurée. Développé par CENTRAL-HEX.
 */
class CommandRouter(
    private val device: DeviceActions,
    private val reminders: ReminderScheduler,
    private val store: LocalStore
) {
    private val callRx = Regex("""^(?:appelle|appeler|telephone a|téléphone à)\s+(.+)$""", RegexOption.IGNORE_CASE)
    private val smsRx = Regex("""^(?:envoie|envoyer) (?:un )?(?:sms|message) a[ux]?\s+(.+?)\s+(?:disant|pour dire|qui dit)\s+(.+)$""", RegexOption.IGNORE_CASE)
    private val openRx = Regex("""^(?:ouvre|ouvrir|lance|lancer)\s+(?:l'application |l'app )?(.+)$""", RegexOption.IGNORE_CASE)
    private val alarmRx = Regex("""^(?:regle|règle|mets|mettre)\s+(?:une\s+)?alarme\s+(?:a|à)\s+(\d{1,2})\s*[h:]\s*(\d{0,2})$""", RegexOption.IGNORE_CASE)
    private val reminderMinRx = Regex("""^rappelle[ -]?moi dans\s+(\d+)\s*min(?:ute)?s?\s+(?:de\s+)?(.+)$""", RegexOption.IGNORE_CASE)
    private val reminderHourRx = Regex("""^rappelle[ -]?moi dans\s+(\d+)\s*h(?:eure)?s?\s+(?:de\s+)?(.+)$""", RegexOption.IGNORE_CASE)
    private val timerMinRx = Regex("""^(?:lance |demarre )?(?:un )?(?:minuteur|chronometre|chronomètre) (?:de\s+)?(\d+)\s*min(?:ute)?s?$""", RegexOption.IGNORE_CASE)

    private val timeRx = Regex("""^quelle heure (?:est-il|il est)[\s?]*$""", RegexOption.IGNORE_CASE)
    private val dateRx = Regex("""^(?:quel jour (?:sommes-nous|on est)|quelle date (?:sommes-nous|on est|aujourd'hui))[\s?]*$""", RegexOption.IGNORE_CASE)
    private val batteryRx = Regex("""^(?:niveau de )?batterie[\s?]*$""", RegexOption.IGNORE_CASE)
    private val flashOnRx = Regex("""^allume(?: la)? (?:lampe|torche)[\s!.]*$""", RegexOption.IGNORE_CASE)
    private val flashOffRx = Regex("""^(?:eteins|éteins)(?: la)? (?:lampe|torche)[\s!.]*$""", RegexOption.IGNORE_CASE)
    private val volUpRx = Regex("""^(?:monte|augmente) le volume[\s!.]*$""", RegexOption.IGNORE_CASE)
    private val volDownRx = Regex("""^(?:baisse|diminue) le volume[\s!.]*$""", RegexOption.IGNORE_CASE)
    private val wifiRx = Regex("""^(?:ouvre|active|allume) le wifi[\s!.]*$""", RegexOption.IGNORE_CASE)
    private val bluetoothRx = Regex("""^(?:ouvre|active|allume) le bluetooth[\s!.]*$""", RegexOption.IGNORE_CASE)
    private val airplaneRx = Regex("""^(?:active|ouvre) le mode avion[\s!.]*$""", RegexOption.IGNORE_CASE)

    private val cameraRx = Regex("""^(?:ouvre l'appareil photo|prends? une photo|ouvre la camera|ouvre la caméra)[\s!.]*$""", RegexOption.IGNORE_CASE)
    private val mapRx = Regex("""^(?:ou suis-je|où suis-je|ouvre la carte|montre moi la carte|ouvre maps)[\s?!.]*$""", RegexOption.IGNORE_CASE)
    private val playPauseRx = Regex("""^(?:joue de la musique|lance la musique|mets en pause|met en pause|pause)[\s!.]*$""", RegexOption.IGNORE_CASE)
    private val nextRx = Regex("""^(?:chanson|piste|musique) suivante[\s!.]*$""", RegexOption.IGNORE_CASE)
    private val prevRx = Regex("""^(?:chanson|piste|musique) (?:precedente|précédente)[\s!.]*$""", RegexOption.IGNORE_CASE)

    private val silentOnRx = Regex("""^(?:active|mets?) le mode silencieux[\s!.]*$""", RegexOption.IGNORE_CASE)
    private val vibrateOnRx = Regex("""^(?:active|mets?) le mode vibreur[\s!.]*$""", RegexOption.IGNORE_CASE)
    private val soundNormalRx = Regex("""^(?:desactive|désactive) le mode silencieux[\s!.]*$""", RegexOption.IGNORE_CASE)
    private val dndOnRx = Regex("""^active ne pas deranger[\s!.]*$""", RegexOption.IGNORE_CASE)
    private val dndOffRx = Regex("""^desactive ne pas deranger[\s!.]*$""", RegexOption.IGNORE_CASE)
    private val lockRx = Regex("""^verrouille(?: l'ecran| l'écran)?[\s!.]*$""", RegexOption.IGNORE_CASE)

    private val noteAddRx = Regex("""^note\s*[:\-]?\s*(.+)$""", RegexOption.IGNORE_CASE)
    private val noteListRx = Regex("""^(?:lis|montre|affiche) (?:mes )?notes[\s?!.]*$""", RegexOption.IGNORE_CASE)
    private val noteClearRx = Regex("""^efface (?:mes )?notes[\s!.]*$""", RegexOption.IGNORE_CASE)

    private val calcRx = Regex("""^(?:calcule|combien (?:font|fait))\s+(.+)$""", RegexOption.IGNORE_CASE)
    private val stopRx = Regex("""^(?:stop|tais[- ]toi|silence)[\s!.]*$""", RegexOption.IGNORE_CASE)
    private val helpRx = Regex("""^(?:aide|que (?:peux|sais)-tu faire|qu'est-ce que tu sais faire)[\s?!.]*$""", RegexOption.IGNORE_CASE)
    private val creatorRx = Regex("""^qui t'a (?:cree|créé|developpe|développé|fait|fabrique|fabriqué)[\s?!.]*$""", RegexOption.IGNORE_CASE)

    fun route(rawText: String, rules: List<AutomationRule>): RouteResult {
        val text = rawText.trim()
        val normalized = normalize(text)

        // 1) Une règle créée par l'utilisateur correspond exactement
        rules.firstOrNull { normalize(it.trigger) == normalized }?.let { return RouteResult.LocalReply(runRule(it)) }

        // 2) Actions avec un paramètre (appeler, SMS, ouvrir une appli, alarme, rappels)
        callRx.find(text)?.let { return RouteResult.LocalReply(device.call(it.groupValues[1].trim())) }
        smsRx.find(text)?.let { return RouteResult.LocalReply(device.sendSms(it.groupValues[1].trim(), it.groupValues[2].trim())) }
        openRx.find(text)?.let { return RouteResult.LocalReply(device.openApp(it.groupValues[1].trim())) }
        alarmRx.find(text)?.let {
            val h = it.groupValues[1].toIntOrNull() ?: return@let
            val m = it.groupValues[2].toIntOrNull() ?: 0
            return RouteResult.LocalReply(device.setAlarm(h, m))
        }
        reminderMinRx.find(text)?.let {
            val n = it.groupValues[1].toIntOrNull() ?: return@let
            return RouteResult.LocalReply(reminders.schedule(n * 60_000L, it.groupValues[2].trim()))
        }
        reminderHourRx.find(text)?.let {
            val n = it.groupValues[1].toIntOrNull() ?: return@let
            return RouteResult.LocalReply(reminders.schedule(n * 3_600_000L, it.groupValues[2].trim()))
        }
        timerMinRx.find(text)?.let {
            val n = it.groupValues[1].toIntOrNull() ?: return@let
            return RouteResult.LocalReply(reminders.schedule(n * 60_000L, "Minuteur de $n minutes terminé."))
        }

        // 3) Infos et réglages du téléphone (fonctionnent sans connexion)
        if (timeRx.matches(text)) return RouteResult.LocalReply(device.currentTime())
        if (dateRx.matches(text)) return RouteResult.LocalReply(device.currentDate())
        if (batteryRx.matches(text)) return RouteResult.LocalReply(device.batteryStatus())
        if (flashOnRx.matches(text)) return RouteResult.LocalReply(device.toggleFlashlight(true))
        if (flashOffRx.matches(text)) return RouteResult.LocalReply(device.toggleFlashlight(false))
        if (volUpRx.matches(text)) return RouteResult.LocalReply(device.adjustVolume(true))
        if (volDownRx.matches(text)) return RouteResult.LocalReply(device.adjustVolume(false))
        if (wifiRx.matches(text)) return RouteResult.LocalReply(device.openSystemSettings("wifi"))
        if (bluetoothRx.matches(text)) return RouteResult.LocalReply(device.openSystemSettings("bluetooth"))
        if (airplaneRx.matches(text)) return RouteResult.LocalReply(device.openAirplaneModeSettings())

        // 4) Appareil photo, carte, musique
        if (cameraRx.matches(text)) return RouteResult.LocalReply(device.openCamera())
        if (mapRx.matches(text)) return RouteResult.LocalReply(device.openMap())
        if (playPauseRx.matches(text)) return RouteResult.LocalReply(device.mediaControl("play_pause"))
        if (nextRx.matches(text)) return RouteResult.LocalReply(device.mediaControl("next"))
        if (prevRx.matches(text)) return RouteResult.LocalReply(device.mediaControl("prev"))

        // 5) Son, Ne pas déranger, verrouillage
        if (silentOnRx.matches(text)) return RouteResult.LocalReply(device.setRingerMode("silencieux"))
        if (vibrateOnRx.matches(text)) return RouteResult.LocalReply(device.setRingerMode("vibreur"))
        if (soundNormalRx.matches(text)) return RouteResult.LocalReply(device.setRingerMode("normal"))
        if (dndOnRx.matches(normalized)) return RouteResult.LocalReply(device.setDoNotDisturb(true))
        if (dndOffRx.matches(normalized)) return RouteResult.LocalReply(device.setDoNotDisturb(false))
        if (lockRx.matches(normalized)) return RouteResult.LocalReply(device.lockScreen())

        // 6) Notes (mémoire locale, 100 % hors ligne)
        noteListRx.find(normalized)?.let { return RouteResult.LocalReply(listNotes()) }
        noteClearRx.find(normalized)?.let { return RouteResult.LocalReply(clearNotes()) }
        noteAddRx.find(text)?.let { return RouteResult.LocalReply(addNote(it.groupValues[1].trim())) }

        // 7) Calcul
        calcRx.find(text)?.let { m ->
            Calculator.evaluate(m.groupValues[1])?.let { return RouteResult.LocalReply(it) }
        }

        // 8) Divers
        if (stopRx.matches(normalized)) return RouteResult.StopSpeaking
        if (helpRx.matches(normalized)) return RouteResult.LocalReply(helpText())
        if (creatorRx.matches(normalized)) return RouteResult.LocalReply("J'ai été développé par CENTRAL-HEX 🇬🇳.")

        // 9) Une règle correspond en partie (ex. trigger "bonsoir" dans "bonsoir jarvis")
        rules.firstOrNull { normalized.contains(normalize(it.trigger)) }?.let { return RouteResult.LocalReply(runRule(it)) }

        // 10) Petites conversations hors-ligne (salutations, politesse...)
        OfflineBrain.answer(normalized)?.let { return RouteResult.LocalReply(it) }

        // 11) Rien de reconnu : on laisse l'IA répondre (nécessite internet + une clé)
        return RouteResult.AskAi(text)
    }

    private fun addNote(text: String): String {
        if (text.isBlank()) return "Dis-moi quoi noter : « note acheter du pain »."
        val s = store.load()
        store.save(s.copy(notes = s.notes + Note(text = text)))
        return "Noté : $text"
    }

    private fun listNotes(): String {
        val notes = store.load().notes
        if (notes.isEmpty()) return "Tu n'as aucune note pour le moment."
        return "Tes notes :\n" + notes.mapIndexed { i, n -> "${i + 1}. ${n.text}" }.joinToString("\n")
    }

    private fun clearNotes(): String {
        val s = store.load()
        val n = s.notes.size
        store.save(s.copy(notes = emptyList()))
        return if (n > 0) "$n note(s) effacée(s)." else "Il n'y avait aucune note."
    }

    private fun helpText(): String = """
        Je peux : appeler, envoyer un SMS, ouvrir une application, régler une alarme,
        créer des rappels et des minuteurs, prendre des notes, faire un calcul,
        te dire l'heure, la date, le niveau de batterie, allumer la lampe torche,
        régler le volume, ouvrir le Wi-Fi, le Bluetooth ou le mode avion, ouvrir
        l'appareil photo ou la carte, contrôler la musique, changer le mode sonore,
        activer Ne pas déranger, verrouiller l'écran, et bien sûr discuter avec toi.
        Je suis JARVIS, développé par CENTRAL-HEX 🇬🇳.
    """.trimIndent().replace("\n", " ")

    private fun runRule(rule: AutomationRule): String = when (rule.actionType) {
        "open_app" -> device.openApp(rule.actionValue)
        "call" -> device.call(rule.actionValue)
        "sms" -> device.sendSms(rule.actionValue, rule.smsBody)
        "say" -> rule.actionValue
        else -> "Règle inconnue."
    }

    private fun normalize(s: String) = s.lowercase()
        .replace("é", "e").replace("è", "e").replace("ê", "e")
        .replace("à", "a").replace("ù", "u").replace("ô", "o")
        .trim()
}
