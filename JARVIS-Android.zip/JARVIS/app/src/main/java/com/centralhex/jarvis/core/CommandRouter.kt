package com.centralhex.jarvis.core

import com.centralhex.jarvis.data.AutomationRule
import com.centralhex.jarvis.data.LocalStore
import com.centralhex.jarvis.data.Note

sealed class RouteResult {
    data class LocalReply(val text: String) : RouteResult()   // traité sur le téléphone, réponse immédiate
    data class AskAi(val text: String) : RouteResult()        // aucune commande reconnue : on demande à l'IA
    object StopSpeaking : RouteResult()                       // "stop" / "tais-toi" : couper la voix, sans réponse parlée
}

/**
 * Comprend les phrases simples en français avant d'appeler l'IA.
 * Ça rend JARVIS rapide et fiable pour les actions courantes, même sans
 * connexion internet ou sans clé IA configurée. Développé par CENTRAL-HEX.
 */
class CommandRouter(
    private val device: DeviceActions,
    private val reminders: ReminderScheduler,
    private val store: LocalStore
) {
    // ───────────── Nettoyage du texte ─────────────

    /** Minuscules, sans accents ni ponctuation : "Allume-moi la torche !" -> "allume moi la torche" */
    private fun base(s: String): String {
        val t = java.text.Normalizer.normalize(s.lowercase(), java.text.Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
        return t.replace(Regex("[^a-z0-9: ]"), " ").replace(Regex("\\s+"), " ").trim()
    }

    private val fillerRx = Regex(
        "\\b(?:jarvis|alors|donc|stp|svp|moi|me|dis|hey|ok|bon|bah|euh|s il te plait|s il vous plait|" +
            "peux tu|pouvez vous|pourrais tu|tu peux|est ce que|veux tu|je veux|je voudrais|j aimerais|voudrais)\\b"
    )

    /** Pareil, mais sans les mots de politesse/remplissage : "peux tu m allumer la torche stp" -> "allumer la torche" */
    private fun clean(s: String): String = base(s).replace(fillerRx, " ").replace(Regex("\\s+"), " ").trim()

    /** Version qui garde majuscules et accents (pour les noms de contacts / d'applis), sans les "-moi" et politesses. */
    private fun soft(s: String): String {
        var t = s.trim()
        t = t.replace(Regex("(?i)\\bjarvis\\b[,\\s]*"), "")
        t = t.replace(Regex("(?i)[- ]moi\\b"), "")
        t = t.replace(Regex("(?i)^(?:(?:alors|donc|stp|svp|hey|ok|bon|peux[- ]tu|pouvez[- ]vous|tu peux|est[- ]ce que tu peux|je veux|je voudrais|j'aimerais|dis)[,\\s]+)+"), "")
        t = t.replace(Regex("(?i)[,\\s]*(?:s'il (?:te|vous) pla[iî]t|stp|svp)[\\s!.?]*$"), "")
        return t.trim()
    }

    private fun has(n: String, vararg words: String) = words.any { n.contains(it) }

    // ───────────── Commandes avec paramètres ─────────────

    private val callRx = Regex("""^(?:appelle|appeler|telephone a|téléphone à|passe un appel a|passe un appel à|contacte)\s+(.+)$""", RegexOption.IGNORE_CASE)
    private val smsRx = Regex("""^(?:envoie|envoyer) (?:un )?(?:sms|message) (?:a|à)[ux]?\s+(.+?)\s+(?:disant|pour dire|qui dit|que)\s+(.+)$""", RegexOption.IGNORE_CASE)
    private val sms2Rx = Regex("""^(?:dis|ecris|écris|texte|envoie un texto)\s+(?:a|à)[ux]?\s+(.+?)\s+(?:que|qu'|:)\s*(.+)$""", RegexOption.IGNORE_CASE)
    private val smsOpenRx = Regex("""^(?:envoie|envoyer|ecris|écris) (?:un )?(?:sms|message|texto)\s+(?:a|à)[ux]?\s+(.+)$""", RegexOption.IGNORE_CASE)
    private val videoRx = Regex("""^(?:mets|met|lance|lancer|joue|jouer|regarde|regarder|cherche|chercher|montre|ouvre)\s+(?:une?\s+|la\s+|les?\s+|des\s+)?(?:videos?)\s*(?:de\s+|d\s+|du\s+|des\s+|sur\s+)?(.*)$""")
    private val videoOnYtRx = Regex("""^(?:cherche|recherche|trouve|mets|met|joue|lance|regarde)\s+(.+?)\s+sur\s+youtube$""")
    private val musicVerbRx = Regex("""^(joue|jouer|ecoute|ecouter|mets|met|lance|lancer|passe|passer|demarre|play)\s+(.*)$""")
    private val musicNounRx = Regex("""\b(?:musique|chanson|morceau|titre|album|playlist)\b""")
    private val musicLeadRx = Regex("""^(?:(?:de la|de l|du|des|la|le|les|une|un|d|l)\s+)?(?:musique|chanson|morceau|titre|album|playlist)s?\s*(?:de\s+|d\s+|du\s+|des\s+)?""")
    private val openRx = Regex(
        """^(?:ouvre|ouvrir|lance|lancer|demarre|démarre|va sur|aller sur|envoie sur|emmene sur|emmène sur|mets sur|met sur|affiche)\s+(?:l'application |l'appli |l'app |l'|la |le |les )?(.+)$""",
        RegexOption.IGNORE_CASE
    )
    private val alarmRx = Regex("""(?:alarme|reveil|reveille)\s*(?:a|pour|de)?\s*(\d{1,2})\s*(?:h|:|heures?)?\s*(\d{0,2})""")
    private val reminderRx = Regex("""rappelle\s+dans\s+(\d+)\s*(minutes?|min|heures?|h)\s+(?:de\s+|d |que\s+|pour\s+)?(.+)""")
    private val timerRx = Regex("""(?:minuteur|chrono\w*|timer)\s+(?:de\s+)?(\d+)\s*(minutes?|min|secondes?|sec|heures?|h)?""")
    private val noteAddRx = Regex("""^(?:note|noter|ajoute(?: une)? note|prends? (?:une )?note)\s*[:\-]?\s*(.+)$""", RegexOption.IGNORE_CASE)
    private val calcRx = Regex("""^(?:calcule|calculer|combien (?:font|fait|vaut|ca fait|ça fait))\s+(.+)$""", RegexOption.IGNORE_CASE)

    fun route(rawText: String, rules: List<AutomationRule>): RouteResult {
        val text = rawText.trim()
        val b = base(text)      // sans accents ni ponctuation
        val n = clean(text)     // + sans politesse/remplissage
        val t = soft(text)      // garde majuscules/accents pour les noms

        // 1) Une règle créée par l'utilisateur correspond exactement
        rules.firstOrNull { base(it.trigger) == b || base(it.trigger) == n }?.let { return RouteResult.LocalReply(runRule(it)) }

        if (n.isEmpty()) return RouteResult.LocalReply("Oui ? Je t'écoute.")

        // 2) Arrêt / aide / identité (en premier, ce sont des phrases courtes)
        if (n == "stop" || n == "tais toi" || n == "silence" || n.startsWith("stop ")) return RouteResult.StopSpeaking
        if (b == "aide" || has(b, "que peux tu faire", "que sais tu faire", "qu est ce que tu sais faire", "tu sais faire quoi", "tes fonctions", "tes commandes"))
            return RouteResult.LocalReply(helpText())
        if (has(b, "qui t a cree", "qui t a developpe", "qui t a fait", "qui t a fabrique", "qui est ton createur", "qui t a cree"))
            return RouteResult.LocalReply("J'ai été développé par CENTRAL-HEX 🇬🇳.")

        // 3) Actions avec paramètres
        callRx.find(t)?.let { return RouteResult.LocalReply(device.call(it.groupValues[1].trim())) }
        smsRx.find(t)?.let { return RouteResult.LocalReply(device.sendSms(it.groupValues[1].trim(), it.groupValues[2].trim())) }
        sms2Rx.find(t)?.let { return RouteResult.LocalReply(device.sendSms(it.groupValues[1].trim(), it.groupValues[2].trim())) }
        smsOpenRx.find(t)?.let { return RouteResult.LocalReply(device.sendSms(it.groupValues[1].trim(), "")) }

        reminderRx.find(n)?.let {
            val k = it.groupValues[1].toLongOrNull() ?: return@let
            val ms = if (it.groupValues[2].startsWith("h")) k * 3_600_000L else k * 60_000L
            return RouteResult.LocalReply(reminders.schedule(ms, it.groupValues[3].trim()))
        }
        timerRx.find(n)?.let {
            val k = it.groupValues[1].toLongOrNull() ?: return@let
            val unit = it.groupValues[2]
            val (ms, label) = when {
                unit.startsWith("h") -> k * 3_600_000L to "$k heure(s)"
                unit.startsWith("s") -> k * 1_000L to "$k seconde(s)"
                else -> k * 60_000L to "$k minute(s)"
            }
            return RouteResult.LocalReply(reminders.schedule(ms, "Minuteur de $label terminé."))
        }
        alarmRx.find(n)?.let {
            val h = it.groupValues[1].toIntOrNull() ?: return@let
            val m = it.groupValues[2].toIntOrNull() ?: 0
            if (h in 0..23 && m in 0..59) return RouteResult.LocalReply(device.setAlarm(h, m))
        }

        // 4) Notes
        if (has(n, "notes") && has(n, "efface", "supprime", "vide", "enleve")) return RouteResult.LocalReply(clearNotes())
        if (has(n, "notes") && (has(n, "lis", "montre", "affiche", "liste", "quelles", "voir", "ouvre") || n == "notes" || n == "mes notes"))
            return RouteResult.LocalReply(listNotes())
        noteAddRx.find(text)?.let { return RouteResult.LocalReply(addNote(it.groupValues[1].trim())) }

        // 5) Calcul
        calcRx.find(n)?.let { m -> Calculator.evaluate(m.groupValues[1])?.let { return RouteResult.LocalReply(it) } }

        // 5b) Pause / suivant / précédent (touches média)
        if (has(n, "suivante", "suivant", "next", "passe la chanson")) return RouteResult.LocalReply(device.mediaControl("next"))
        if (has(n, "precedente", "precedent", "revenir en arriere")) return RouteResult.LocalReply(device.mediaControl("prev"))
        if (n == "pause" || n == "play" || has(n, "mets en pause", "met en pause", "reprends la lecture", "arrete la musique", "coupe la musique", "stoppe la musique"))
            return RouteResult.LocalReply(device.mediaControl("play_pause"))

        // 5c) Vidéo (YouTube)
        videoOnYtRx.find(n)?.let { return RouteResult.LocalReply(device.searchVideo(it.groupValues[1].trim())) }
        videoRx.find(n)?.let { return RouteResult.LocalReply(device.searchVideo(it.groupValues[1].trim())) }

        // 5d) Musique : "joue Burna Boy", "mets de la musique de Stromae", "joue de la musique"
        musicVerbRx.find(n)?.let { m ->
            val verb = m.groupValues[1]
            val rest = m.groupValues[2].trim()
            val generic = verb in setOf("joue", "jouer", "ecoute", "ecouter", "play")
            if (generic || musicNounRx.containsMatchIn(rest)) {
                var query = rest
                repeat(2) { query = query.replace(musicLeadRx, "").trim() }
                return RouteResult.LocalReply(device.playMusic(query))
            }
        }

        // 5e) Galerie
        if (has(n, "galerie", "mes photos", "mes images", "mes videos")) return RouteResult.LocalReply(device.openGallery())

        // 6) Infos du téléphone (fonctionnent sans connexion), par mots-clés : "quel heure fait il", "il est quelle heure"…
        if (has(n, "heure") && !has(n, "alarme", "reveil", "rappel", "minuteur")) return RouteResult.LocalReply(device.currentTime())
        if (has(n, "quel jour", "quelle date", "date d aujourd", "on est quel jour", "jour sommes", "date aujourd")) return RouteResult.LocalReply(device.currentDate())
        if (has(n, "batterie", "niveau de charge", "combien de pourcent")) return RouteResult.LocalReply(device.batteryStatus())

        // 7) Lampe torche
        if (has(n, "torche", "lampe", "flash", "lumiere")) {
            return if (has(n, "eteins", "eteint", "eteindre", "coupe", "desactive", "arrete", "ferme"))
                RouteResult.LocalReply(device.toggleFlashlight(false))
            else RouteResult.LocalReply(device.toggleFlashlight(true))
        }

        // 8) Volume, Wi-Fi, Bluetooth, avion
        if (has(n, "volume") || n == "plus fort" || n == "moins fort") {
            return if (has(n, "baisse", "diminue", "reduis", "moins fort", "plus bas", "descend"))
                RouteResult.LocalReply(device.adjustVolume(false))
            else RouteResult.LocalReply(device.adjustVolume(true))
        }
        if (has(n, "wifi", "wi fi")) return RouteResult.LocalReply(device.openSystemSettings("wifi"))
        if (has(n, "bluetooth")) return RouteResult.LocalReply(device.openSystemSettings("bluetooth"))
        if (has(n, "mode avion")) return RouteResult.LocalReply(device.openAirplaneModeSettings())

        // 9) Appareil photo, carte, musique
        if (has(n, "appareil photo", "camera", "prends une photo", "prendre une photo", "selfie")) return RouteResult.LocalReply(device.openCamera())
        if (has(n, "ou suis je", "ma position", "la carte", "maps", "google maps", "itineraire")) return RouteResult.LocalReply(device.openMap())

        // 10) Son, Ne pas déranger, verrouillage
        if (has(n, "ne pas deranger")) {
            return RouteResult.LocalReply(device.setDoNotDisturb(!has(n, "desactive", "coupe", "enleve", "arrete", "retire")))
        }
        if (has(n, "silencieux", "silence mode")) {
            return RouteResult.LocalReply(device.setRingerMode(if (has(n, "desactive", "enleve", "retire", "annule", "normal", "sors")) "normal" else "silencieux"))
        }
        if (has(n, "vibreur", "vibration")) return RouteResult.LocalReply(device.setRingerMode("vibreur"))
        if (n.startsWith("verrouille") || has(n, "bloque l ecran", "verrouiller l ecran", "eteins l ecran", "eteindre l ecran"))
            return RouteResult.LocalReply(device.lockScreen())

        // 11) Ouvrir une application (en dernier pour ne pas voler "ouvre le wifi", "ouvre la caméra"…)
        openRx.find(t)?.let { return RouteResult.LocalReply(device.openApp(it.groupValues[1].trim())) }

        // 12) Une règle correspond en partie (ex. déclencheur "bonsoir" dans "bonsoir jarvis")
        rules.firstOrNull { base(it.trigger).isNotEmpty() && (b.contains(base(it.trigger)) || n.contains(base(it.trigger))) }
            ?.let { return RouteResult.LocalReply(runRule(it)) }

        // 13) Petites conversations hors-ligne (salutations, politesse...)
        OfflineBrain.answer(n)?.let { return RouteResult.LocalReply(it) }

        // 14) Rien de reconnu : on laisse l'IA répondre (nécessite internet + une clé)
        return RouteResult.AskAi(text)
    }

    private fun addNote(text: String): String {
        if (text.isBlank()) return "Dis-moi quoi noter : « note acheter du pain »."
        val s = store.load()
        store.save(s.copy(notes = s.notes + Note(text = text)))
        return "Noté : $text"
    }

    private fun listNotes(): String {
        val notes = store.load().notes
        if (notes.isEmpty()) return "Tu n'as aucune note pour le moment."
        return "Tes notes :\n" + notes.mapIndexed { i, n -> "${i + 1}. ${n.text}" }.joinToString("\n")
    }

    private fun clearNotes(): String {
        val s = store.load()
        val n = s.notes.size
        store.save(s.copy(notes = emptyList()))
        return if (n > 0) "$n note(s) effacée(s)." else "Il n'y avait aucune note."
    }

    private fun helpText(): String = """
        Je peux : appeler, envoyer un SMS, ouvrir une application, régler une alarme,
        créer des rappels et des minuteurs, prendre des notes, faire un calcul,
        te dire l'heure, la date, le niveau de batterie, allumer la lampe torche,
        régler le volume, ouvrir le Wi-Fi, le Bluetooth ou le mode avion, ouvrir
        l'appareil photo ou la carte, contrôler la musique, changer le mode sonore,
        activer Ne pas déranger, verrouiller l'écran, et bien sûr discuter avec toi.
        Je suis JARVIS, développé par CENTRAL-HEX 🇬🇳.
    """.trimIndent().replace("\n", " ")

    private fun runRule(rule: AutomationRule): String = when (rule.actionType) {
        "open_app" -> device.openApp(rule.actionValue)
        "call" -> device.call(rule.actionValue)
        "sms" -> device.sendSms(rule.actionValue, rule.smsBody)
        "say" -> rule.actionValue
        else -> "Règle inconnue."
    }
}
