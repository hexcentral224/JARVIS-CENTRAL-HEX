package com.centralhex.jarvis.core

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Le « Voice Access » de JARVIS : agit sur n'importe quelle application (accueil, retour, notifications,
 * appuyer sur un bouton par son nom ou son numéro, défiler, écrire du texte).
 * À activer une fois dans Paramètres ▸ Accessibilité ▸ JARVIS.
 */
class JarvisAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: JarvisAccessibilityService? = null
            private set
        val isRunning: Boolean get() = instance != null
    }

    private var numbersView: View? = null
    private var numbered: List<AccessibilityNodeInfo> = emptyList()

    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: android.content.Intent?): Boolean { hideNumbers(); instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { hideNumbers(); instance = null; super.onDestroy() }

    // ───────────── Actions globales ─────────────

    fun home(): String = if (performGlobalAction(GLOBAL_ACTION_HOME)) "Accueil." else "Je n'ai pas pu revenir à l'accueil."
    fun back(): String = if (performGlobalAction(GLOBAL_ACTION_BACK)) "Retour." else "Je n'ai pas pu revenir en arrière."
    fun recents(): String = if (performGlobalAction(GLOBAL_ACTION_RECENTS)) "Applications récentes." else "Impossible d'ouvrir les applications récentes."
    fun notifications(): String = if (performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)) "Voici les notifications." else "Impossible d'ouvrir les notifications."
    fun quickSettings(): String = if (performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)) "Voici les réglages rapides." else "Impossible d'ouvrir les réglages rapides."
    fun powerMenu(): String = if (performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)) "Menu d'alimentation." else "Impossible d'ouvrir le menu d'alimentation."

    fun screenshot(): String =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)) "Capture d'écran faite."
        else "Je n'ai pas pu faire de capture d'écran."

    // ───────────── Parcours de l'écran ─────────────

    private inline fun walk(node: AccessibilityNodeInfo?, visit: (AccessibilityNodeInfo) -> Unit) {
        if (node == null) return
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(node)
        while (stack.isNotEmpty()) {
            val n = stack.removeLast()
            visit(n)
            for (i in 0 until n.childCount) n.getChild(i)?.let { stack.add(it) }
        }
    }

    private fun screenSize(): Pair<Int, Int> {
        val m = resources.displayMetrics
        return m.widthPixels to m.heightPixels
    }

    // ───────────── Toucher ─────────────

    private fun tap(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 70)).build()
        return dispatchGesture(g, null, null)
    }

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long = 320): Boolean {
        val path = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, ms)).build()
        return dispatchGesture(g, null, null)
    }

    private fun clickNode(node: AccessibilityNodeInfo, longPress: Boolean = false): Boolean {
        var n: AccessibilityNodeInfo? = node
        while (n != null) {
            if (if (longPress) n.isLongClickable else n.isClickable) {
                return n.performAction(if (longPress) AccessibilityNodeInfo.ACTION_LONG_CLICK else AccessibilityNodeInfo.ACTION_CLICK)
            }
            n = n.parent
        }
        val r = Rect(); node.getBoundsInScreen(r)
        return tap(r.exactCenterX(), r.exactCenterY())      // pas de parent cliquable : on touche à l'endroit exact
    }

    /** « Appuie sur Envoyer » : retrouve l'élément dont le texte ou la description RESSEMBLE le plus (à l'oreille). */
    fun clickLabel(label: String, longPress: Boolean = false): String {
        val root = rootInActiveWindow ?: return "Je ne vois pas l'écran."
        val wanted = Fuzzy.clean(label)
        var best: AccessibilityNodeInfo? = null
        var bestScore = 0.0
        walk(root) { n ->
            if (!n.isVisibleToUser) return@walk
            val labels = listOfNotNull(n.text?.toString(), n.contentDescription?.toString(), n.viewIdResourceName?.substringAfterLast('/'))
            for (s in labels) {
                if (s.isBlank() || s.length > 60) continue
                var score = Fuzzy.similarity(label, s)
                val c = Fuzzy.clean(s)
                if (wanted.length >= 2 && c == wanted) score = 1.0
                else if (wanted.length >= 3 && c.contains(wanted)) score = maxOf(score, 0.9)
                if (score > bestScore) { bestScore = score; best = n }
            }
        }
        val target = best
        if (target == null || bestScore < 0.72) return "Je ne vois pas « $label » à l'écran."
        return if (clickNode(target, longPress)) "J'appuie sur $label." else "Je n'ai pas réussi à appuyer sur $label."
    }

    // ───────────── Numéros à l'écran (comme Voice Access) ─────────────

    fun showNumbers(): String {
        hideNumbers()
        val root = rootInActiveWindow ?: return "Je ne vois pas l'écran."
        val items = mutableListOf<Pair<Rect, AccessibilityNodeInfo>>()
        walk(root) { n ->
            if (n.isVisibleToUser && (n.isClickable || n.isLongClickable)) {
                val r = Rect(); n.getBoundsInScreen(r)
                if (r.width() > 24 && r.height() > 24) items.add(r to n)
            }
        }
        val chosen = items.take(99)
        if (chosen.isEmpty()) return "Je ne trouve rien sur quoi appuyer ici."
        numbered = chosen.map { it.second }

        val view = object : View(this) {
            private val box = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.argb(200, 34, 211, 255); strokeWidth = 3f }
            private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(235, 34, 211, 255) }
            private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(2, 6, 15); textSize = 34f; isFakeBoldText = true }
            override fun onDraw(canvas: Canvas) {
                chosen.forEachIndexed { i, (r, _) ->
                    canvas.drawRect(RectF(r), box)
                    val label = (i + 1).toString()
                    val w = txt.measureText(label) + 18f
                    canvas.drawRoundRect(RectF(r.left.toFloat(), r.top.toFloat(), r.left + w, r.top + 44f), 10f, 10f, bg)
                    canvas.drawText(label, r.left + 9f, r.top + 33f, txt)
                }
            }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        try { wm.addView(view, lp); numbersView = view } catch (e: Exception) { return "Je n'ai pas pu afficher les numéros." }
        return "Voici les numéros. Dis « appuie sur 3 » par exemple."
    }

    fun hideNumbers(): String {
        numbersView?.let { v ->
            try { (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v) } catch (e: Exception) {}
        }
        numbersView = null
        return "Numéros masqués."
    }

    fun tapNumber(n: Int): String {
        // Pas de numéros affichés : « appuie sur 6 » veut dire la touche « 6 » (calculatrice, clavier…)
        if (numbersView == null) return clickLabel(n.toString())
        val node = numbered.getOrNull(n - 1) ?: return "Le numéro $n n'existe pas. Dis « montre les numéros » d'abord."
        hideNumbers()
        return if (clickNode(node)) "J'appuie sur le $n." else "Je n'ai pas réussi à appuyer sur le $n."
    }

    // ───────────── Défilement ─────────────

    private fun findScrollable(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var best: AccessibilityNodeInfo? = null
        var bestArea = 0
        walk(root) { n ->
            if (n.isScrollable && n.isVisibleToUser) {
                val r = Rect(); n.getBoundsInScreen(r)
                val area = r.width() * r.height()
                if (area > bestArea) { bestArea = area; best = n }
            }
        }
        return best
    }

    fun scroll(direction: String): String {
        val root = rootInActiveWindow
        val node = root?.let { findScrollable(it) }
        val action = when (direction) {
            "haut" -> AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            "gauche" -> AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_LEFT.id
            "droite" -> AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_RIGHT.id
            else -> AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        }
        if (node != null && node.performAction(action)) return "Je fais défiler vers le $direction."
        // aucun élément défilant détecté : on fait glisser le doigt
        val (w, h) = screenSize()
        val ok = when (direction) {
            "haut" -> swipe(w / 2f, h * 0.3f, w / 2f, h * 0.7f)
            "gauche" -> swipe(w * 0.2f, h / 2f, w * 0.8f, h / 2f)
            "droite" -> swipe(w * 0.8f, h / 2f, w * 0.2f, h / 2f)
            else -> swipe(w / 2f, h * 0.7f, w / 2f, h * 0.3f)
        }
        return if (ok) "Je fais défiler vers le $direction." else "Je n'ai pas pu faire défiler."
    }

    // ───────────── Texte ─────────────

    private fun focusedInput(): AccessibilityNodeInfo? = findFocus(AccessibilityNodeInfo.FOCUS_INPUT)

    fun hasFocusedInput(): Boolean = focusedInput() != null

    fun type(text: String): String {
        val node = focusedInput() ?: return "Touche d'abord un champ de texte, puis redis-moi quoi écrire."
        val hint = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) node.hintText?.toString() else null
        var current = node.text?.toString().orEmpty()
        if (current == hint) current = ""
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, if (current.isEmpty()) text else "$current $text")
        }
        return if (node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) "C'est écrit." else "Je n'ai pas pu écrire ici."
    }

    fun clearText(): String {
        val node = focusedInput() ?: return "Aucun champ de texte n'est sélectionné."
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "") }
        return if (node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) "Texte effacé." else "Je n'ai pas pu effacer."
    }

    fun enter(): String {
        val node = focusedInput() ?: return "Aucun champ de texte n'est sélectionné."
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R &&
            node.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)) "Validé."
        else "Je n'ai pas pu valider."
    }
}
