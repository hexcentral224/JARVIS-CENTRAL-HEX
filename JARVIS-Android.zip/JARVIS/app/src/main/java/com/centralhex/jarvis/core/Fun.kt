package com.centralhex.jarvis.core

import kotlin.random.Random

/** Petites fonctions bonus, toutes hors ligne : dé, pile ou face, blagues, citations, conversions. */
object Fun {

    fun coin() = if (Random.nextBoolean()) "Pile." else "Face."

    fun dice() = "Le dé a roulé : ${Random.nextInt(1, 7)}."

    fun randomBetween(a: Int, b: Int): String {
        val lo = minOf(a, b)
        val hi = maxOf(a, b)
        return "Mon choix entre $lo et $hi : ${Random.nextInt(lo, hi + 1)}."
    }

    private val jokes = listOf(
        "Pourquoi les plongeurs plongent-ils toujours en arrière ? Parce que sinon ils tombent dans le bateau.",
        "Que dit un câble qui n'a plus de batterie ? Je suis à plat, mais je reste branché sur toi.",
        "Pourquoi l'ordinateur est-il allé chez le médecin ? Parce qu'il avait un virus.",
        "Quel est le comble pour un électricien ? De ne pas être au courant.",
        "Qu'est-ce qu'un crocodile qui surveille la pharmacie ? Un Lacoste garde.",
        "Pourquoi les téléphones n'ont-ils jamais froid ? Parce qu'ils ont toujours un coque.",
        "Que fait un geek quand il a peur ? Il se met en mode avion."
    )

    private val quotes = listOf(
        "Chaque grande réussite commence par la décision d'essayer.",
        "On n'a pas besoin d'être parfait pour commencer, mais il faut commencer pour progresser.",
        "Le talent ouvre la porte, la discipline te fait rester dans la pièce.",
        "Tes projets d'aujourd'hui sont la réalité de demain. Continue.",
        "Un petit pas chaque jour vaut mieux qu'un grand saut jamais fait.",
        "La vision sans action est un rêve, l'action sans vision est du bruit. Réunis les deux."
    )

    fun joke() = jokes.random()
    fun quote() = quotes.random()

    // ── Conversions ──
    private data class U(val dim: String, val factor: Double)

    private val units: Map<String, U> = buildMap {
        fun add(f: Double, d: String, vararg names: String) = names.forEach { put(it, U(d, f)) }
        add(1000.0, "long", "km", "kilometre", "kilometres")
        add(1609.344, "long", "mile", "miles")
        add(1.0, "long", "m", "metre", "metres")
        add(0.3048, "long", "pied", "pieds")
        add(0.01, "long", "cm", "centimetre", "centimetres")
        add(1000.0, "mass", "kg", "kilo", "kilos", "kilogramme", "kilogrammes")
        add(453.592, "mass", "livre", "livres", "lb")
        add(1.0, "mass", "g", "gramme", "grammes")
        add(1000.0, "vol", "litre", "litres", "l")
        add(3785.41, "vol", "gallon", "gallons")
        add(1.0, "vol", "ml", "millilitre", "millilitres")
    }

    private fun fmt(x: Double): String {
        val r = Math.round(x * 100) / 100.0
        return if (r == r.toLong().toDouble()) r.toLong().toString() else r.toString().replace('.', ',')
    }

    fun convert(value: Double, from: String, to: String): String? {
        val f = from.lowercase(); val t = to.lowercase()
        val celsius = setOf("celsius", "degre", "degres", "c")
        val fahr = setOf("fahrenheit", "f")
        if (f in celsius && t in fahr) return "${fmt(value)} °C font ${fmt(value * 9 / 5 + 32)} °F."
        if (f in fahr && t in celsius) return "${fmt(value)} °F font ${fmt((value - 32) * 5 / 9)} °C."
        val a = units[f] ?: return null
        val b = units[t] ?: return null
        if (a.dim != b.dim) return null
        return "${fmt(value)} $from font ${fmt(value * a.factor / b.factor)} $to."
    }
}
