package com.centralhex.jarvis.core

import com.centralhex.jarvis.data.ChatMessage
import com.centralhex.jarvis.data.JarvisSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

/**
 * Appelle une IA compatible avec le format OpenAI (Groq, OpenRouter, etc.).
 * Aucune clé n'est écrite dans le code : la personne la colle dans Réglages,
 * elle reste stockée uniquement sur son téléphone.
 */
class AiClient {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .build()

    private val persona = """
        Tu es JARVIS, l'assistant personnel du propriétaire de ce téléphone Android,
        développé par CENTRAL-HEX 🇬🇳. Si on te demande qui t'a créé ou développé,
        réponds que c'est CENTRAL-HEX. Réponds dans la langue utilisée par la personne
        (français par défaut), de façon directe, utile et un peu posée, comme un
        majordome efficace. Garde tes réponses courtes (elles peuvent être lues à
        voix haute), sauf si on te demande des détails. Tu n'as pas de corps ni de
        capacités en dehors de ce téléphone : ne prétends pas agir sur le monde réel
        au-delà de ce que l'application te permet (appeler, envoyer un SMS, ouvrir
        une appli, régler un rappel, prendre une note, faire un calcul).
    """.trimIndent()

    companion object {
        /** Modèle trouvé automatiquement quand celui des Réglages n'existe plus chez le fournisseur. */
        @Volatile var discoveredModel: String? = null
    }

    private val unwanted = listOf("whisper", "guard", "tts", "playai", "embed", "orpheus", "moderation", "safeguard", "vision-preview")
    private val preferred = listOf("llama-3.3-70b", "llama-3.1-8b-instant", "gpt-oss-120b", "gpt-oss-20b", "llama-4", "llama3", "qwen", "gemma", "mixtral")

    /** Demande au fournisseur la liste de ses modèles et choisit un modèle de discussion disponible. */
    private fun discoverModel(settings: JarvisSettings): String? = try {
        val req = Request.Builder()
            .url(settings.aiBaseUrl.trimEnd('/') + "/models")
            .addHeader("Authorization", "Bearer ${settings.aiApiKey}")
            .get().build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) null else {
                val ids = Json.parseToJsonElement(resp.body?.string().orEmpty()).jsonObject["data"]
                    ?.jsonArray?.mapNotNull { it.jsonObject["id"]?.jsonPrimitive?.contentOrNull }
                    ?.filter { id -> unwanted.none { id.contains(it, ignoreCase = true) } }
                    .orEmpty()
                preferred.firstNotNullOfOrNull { p -> ids.firstOrNull { it.contains(p, ignoreCase = true) } } ?: ids.firstOrNull()
            }
        }
    } catch (e: Exception) { null }

    private fun friendlyError(code: Int, body: String): String = when (code) {
        401, 403 -> "Clé IA refusée. Vérifie qu'elle est bien copiée en entier dans Réglages."
        429 -> "Limite gratuite atteinte pour le moment. Réessaie dans une minute."
        in 500..599 -> "Le service d'IA est en panne pour le moment. Réessaie plus tard."
        else -> "Erreur IA ($code) : ${body.take(120)}"
    }

    suspend fun ask(history: List<ChatMessage>, settings: JarvisSettings): Result<String> =
        withContext(Dispatchers.IO) {
            if (settings.aiApiKey.isBlank()) {
                return@withContext Result.failure(
                    IllegalStateException("Je n'ai pas compris cette commande. Dis « aide » pour voir ce que je sais faire sans internet. Pour répondre aux questions ouvertes, ajoute une clé IA gratuite dans Réglages (console.groq.com).")
                )
            }
            try {
                val messages = buildJsonArray {
                    add(buildJsonObject { put("role", "system"); put("content", persona) })
                    for (m in history.takeLast(16)) {
                        add(buildJsonObject {
                            put("role", if (m.fromUser) "user" else "assistant")
                            put("content", m.text)
                        })
                    }
                }

                fun call(model: String): Pair<Int, String> {
                    val payload = buildJsonObject {
                        put("model", model)
                        put("temperature", 0.6)
                        put("max_tokens", 500)
                        put("messages", messages)
                    }.toString()
                    val request = Request.Builder()
                        .url(settings.aiBaseUrl.trimEnd('/') + "/chat/completions")
                        .addHeader("Authorization", "Bearer ${settings.aiApiKey}")
                        .post(payload.toRequestBody("application/json".toMediaType()))
                        .build()
                    return client.newCall(request).execute().use { resp -> resp.code to resp.body?.string().orEmpty() }
                }

                var (code, body) = call(discoveredModel ?: settings.aiModel)
                // Modèle supprimé ou inaccessible : on en cherche un autre automatiquement, une seule fois.
                if (code == 404 || (code == 400 && body.contains("model", ignoreCase = true))) {
                    val found = discoverModel(settings)
                    if (found != null) { discoveredModel = found; val r = call(found); code = r.first; body = r.second }
                }
                if (code !in 200..299) return@withContext Result.failure(Exception(friendlyError(code, body)))

                val root = Json.parseToJsonElement(body).jsonObject
                val text = root["choices"]?.jsonArray?.firstOrNull()
                    ?.jsonObject?.get("message")?.jsonObject?.get("content")
                    ?.jsonPrimitive?.contentOrNull
                if (text.isNullOrBlank()) Result.failure(Exception("Réponse vide de l'IA."))
                else Result.success(text.trim())
            } catch (e: java.io.IOException) {
                Result.failure(Exception("Pas de connexion internet. Les commandes du téléphone (appels, alarmes, lampe, notes, calcul…) marchent hors ligne, mais cette question a besoin d'internet."))
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
}
