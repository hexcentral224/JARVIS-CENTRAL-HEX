package com.centralhex.jarvis.core

import com.centralhex.jarvis.data.ChatMessage
import com.centralhex.jarvis.data.JarvisSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

/**
 * Appelle une IA compatible avec le format OpenAI (Groq, OpenRouter, etc.).
 * Aucune clé n'est écrite dans le code : la personne la colle dans Réglages,
 * elle reste stockée uniquement sur son téléphone.
 */
class AiClient {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .build()

    private val persona = """
        Tu es JARVIS, l'assistant personnel du propriétaire de ce téléphone Android,
        développé par CENTRAL-HEX 🇬🇳. Si on te demande qui t'a créé ou développé,
        réponds que c'est CENTRAL-HEX. Réponds dans la langue utilisée par la personne
        (français par défaut), de façon directe, utile et un peu posée, comme un
        majordome efficace. Garde tes réponses courtes (elles peuvent être lues à
        voix haute), sauf si on te demande des détails. Tu n'as pas de corps ni de
        capacités en dehors de ce téléphone : ne prétends pas agir sur le monde réel
        au-delà de ce que l'application te permet (appeler, envoyer un SMS, ouvrir
        une appli, régler un rappel, prendre une note, faire un calcul).
    """.trimIndent()

    suspend fun ask(history: List<ChatMessage>, settings: JarvisSettings): Result<String> =
        withContext(Dispatchers.IO) {
            if (settings.aiApiKey.isBlank()) {
                return@withContext Result.failure(
                    IllegalStateException("Aucune clé IA renseignée. Ouvre Réglages et colle une clé gratuite (ex. console.groq.com).")
                )
            }
            try {
                val messages = buildJsonArray {
                    add(buildJsonObject { put("role", "system"); put("content", persona) })
                    for (m in history.takeLast(16)) {
                        add(buildJsonObject {
                            put("role", if (m.fromUser) "user" else "assistant")
                            put("content", m.text)
                        })
                    }
                }
                val payload = buildJsonObject {
                    put("model", settings.aiModel)
                    put("temperature", 0.6)
                    put("max_tokens", 500)
                    put("messages", messages)
                }.toString()

                val url = settings.aiBaseUrl.trimEnd('/') + "/chat/completions"
                val request = Request.Builder()
                    .url(url)
                    .addHeader("Authorization", "Bearer ${settings.aiApiKey}")
                    .post(payload.toRequestBody("application/json".toMediaType()))
                    .build()

                client.newCall(request).execute().use { resp ->
                    val body = resp.body?.string().orEmpty()
                    if (!resp.isSuccessful) {
                        return@withContext Result.failure(Exception("Erreur IA (${resp.code}) : ${body.take(200)}"))
                    }
                    val root = Json.parseToJsonElement(body).jsonObject
                    val text = root["choices"]?.jsonArray?.firstOrNull()
                        ?.jsonObject?.get("message")?.jsonObject?.get("content")
                        ?.jsonPrimitive?.contentOrNull
                    if (text.isNullOrBlank()) Result.failure(Exception("Réponse vide de l'IA."))
                    else Result.success(text.trim())
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
}
