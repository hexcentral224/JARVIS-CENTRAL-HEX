package com.centralhex.jarvis.data

import kotlinx.serialization.Serializable

@Serializable
data class ChatMessage(
    val id: Long = System.currentTimeMillis(),
    val fromUser: Boolean,
    val text: String
)

/**
 * Règle d'automatisation très simple : "quand je dis <trigger>, <action>".
 * C'est volontairement local et déclenché par la voix/le texte (pas un service
 * d'accessibilité qui surveillerait le téléphone en arrière-plan).
 */
@Serializable
data class AutomationRule(
    val id: Long = System.currentTimeMillis(),
    val trigger: String,       // phrase qui déclenche la règle (comparée en minuscules, sans accents)
    val actionType: String,    // "open_app" | "call" | "sms" | "say"
    val actionValue: String,   // nom de l'appli / numéro / message selon actionType
    val smsBody: String = ""   // uniquement pour actionType = "sms"
)

@Serializable
data class Note(
    val id: Long = System.currentTimeMillis(),
    val text: String
)

@Serializable
data class JarvisSettings(
    val aiApiKey: String = "",
    val aiBaseUrl: String = "https://api.groq.com/openai/v1",
    val aiModel: String = "llama-3.3-70b-versatile",
    val autoSpeak: Boolean = true,
    val wakeWordEnabled: Boolean = true,
    val darkTheme: Boolean = true,
    val floatingOrb: Boolean = true
)

@Serializable
data class AppState(
    val settings: JarvisSettings = JarvisSettings(),
    val rules: List<AutomationRule> = emptyList(),
    val history: List<ChatMessage> = emptyList(),
    val notes: List<Note> = emptyList(),
    val activityLog: List<ActivityEntry> = emptyList()
)

@Serializable
data class ActivityEntry(
    val id: Long = System.currentTimeMillis(),
    val label: String
)
