package com.centralhex.jarvis.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.centralhex.jarvis.ui.theme.HexGreen
import com.centralhex.jarvis.ui.theme.HexRed
import kotlin.math.cos
import kotlin.math.sin

enum class OrbState { IDLE, LISTENING, THINKING, SPEAKING }

/**
 * L'hexagone animé de JARVIS : respire doucement au repos, s'accélère et
 * pulse quand il écoute ou réfléchit. Utilisé sur l'accueil et sur l'écran
 * de réveil plein écran.
 */
@Composable
fun HexOrb(state: OrbState, size: Dp, color: Color, modifier: Modifier = Modifier) {
    val speed = when (state) { OrbState.IDLE -> 3600; OrbState.THINKING -> 1400; else -> 900 }
    val infinite = rememberInfiniteTransition(label = "hexOrb")

    val rotation by infinite.animateFloat(
        0f, 360f,
        infiniteRepeatable(tween(speed, easing = LinearEasing)), label = "rot"
    )
    val pulse by infinite.animateFloat(
        0.82f, 1f,
        infiniteRepeatable(tween(speed / 3, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse"
    )

    val accent = when (state) {
        OrbState.LISTENING -> HexRed
        OrbState.THINKING, OrbState.SPEAKING -> HexGreen
        OrbState.IDLE -> color
    }

    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(size)) {
            val c = Offset(size.toPx() / 2, size.toPx() / 2)
            val r1 = size.toPx() / 2 * pulse
            val r2 = r1 * 0.72f

            fun hex(radius: Float, rot: Float): List<Offset> =
                (0 until 6).map { i ->
                    val a = Math.toRadians((rot + i * 60).toDouble())
                    Offset(c.x + radius * cos(a).toFloat(), c.y + radius * sin(a).toFloat())
                }

            val outer = hex(r1, rotation)
            for (i in outer.indices) {
                drawLine(accent.copy(alpha = 0.9f), outer[i], outer[(i + 1) % 6], strokeWidth = 3f, cap = StrokeCap.Round)
            }
            val inner = hex(r2, -rotation * 1.4f)
            for (i in inner.indices) {
                drawLine(color.copy(alpha = 0.5f), inner[i], inner[(i + 1) % 6], strokeWidth = 2f, cap = StrokeCap.Round)
            }
            drawCircle(accent.copy(alpha = 0.18f), radius = r2 * 0.55f, center = c)
            drawCircle(accent, radius = 4f, center = c)
            drawCircle(
                accent.copy(alpha = 0.5f), radius = r1 + 4f, center = c,
                style = Stroke(width = 1.5f)
            )
        }
    }
}
