package com.centralhex.jarvis.ui.theme

import androidx.compose.ui.graphics.Color

// Palette CENTRAL-HEX : noir et blanc, minimaliste, hexagones lumineux
val HexBg = Color(0xFF07070A)
val HexSurface = Color(0xFF111115)
val HexCard = Color(0xFF17171C)
val HexLine = Color(0xFF26262E)
val HexWhite = Color(0xFFF2F2F5)
val HexMuted = Color(0xFF8A8A95)
val HexGreen = Color(0xFF34D17E)   // statuts "connecté / en ligne"
val HexRed = Color(0xFFFF4D5E)     // écoute active / alerte

val HexBubbleAi = Color(0xFF15151A)
val HexBubbleUser = Color(0xFF1F1F26)

// Thème clair (facultatif, bascule dans Réglages)
val HexBgLight = Color(0xFFF4F4F6)
val HexCardLight = Color(0xFFFFFFFF)
val HexLineLight = Color(0xFFE2E2E6)
val HexTextLight = Color(0xFF131316)
val HexMutedLight = Color(0xFF6B6B74)
