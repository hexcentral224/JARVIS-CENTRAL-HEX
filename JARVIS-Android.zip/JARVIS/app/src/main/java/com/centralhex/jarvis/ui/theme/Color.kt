package com.centralhex.jarvis.ui.theme

import androidx.compose.ui.graphics.Color

// ── Palette HUD « Iron Man » : noir bleuté, bleu arc réacteur, or en touche ──
val HudBg = Color(0xFF02060F)
val HudPanel = Color(0xFF07111F)
val HudCyan = Color(0xFF22D3FF)
val HudBlue = Color(0xFF1E90FF)
val HudGold = Color(0xFFFFC857)
val HudRed = Color(0xFFFF4D5E)
val HudGreen = Color(0xFF2EE6A8)
val HudText = Color(0xFFE6F6FF)
val HudMuted = Color(0xFF6E8AA3)
val HudLine = Color(0xFF123A5C)

// Anciens noms conservés (les autres écrans les utilisent), avec les nouvelles couleurs
val HexBg = HudBg
val HexSurface = Color(0xFF050D19)
val HexCard = HudPanel
val HexLine = HudLine
val HexWhite = HudText
val HexMuted = HudMuted
val HexGreen = HudGreen
val HexRed = HudRed
val HexBubbleAi = Color(0xFF0A1A2D)
val HexBubbleUser = Color(0xFF0E2A47)

// Thème clair supprimé : l'appli est toujours en mode HUD sombre
val HexBgLight = Color(0xFFF4F4F6)
val HexCardLight = Color(0xFFFFFFFF)
val HexLineLight = Color(0xFFE2E2E6)
val HexTextLight = Color(0xFF131316)
val HexMutedLight = Color(0xFF6B6B74)
