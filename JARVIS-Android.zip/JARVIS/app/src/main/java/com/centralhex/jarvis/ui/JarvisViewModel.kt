package com.centralhex.jarvis.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.centralhex.jarvis.core.AiClient
import com.centralhex.jarvis.core.CommandRouter
import com.centralhex.jarvis.core.DeviceActions
import com.centralhex.jarvis.core.ReminderScheduler
import com.centralhex.jarvis.core.RouteResult
import com.centralhex.jarvis.core.VoiceManager
import com.centralhex.jarvis.core.WakeWordService
import com.centralhex.jarvis.data.ActivityEntry
import com.centralhex.jarvis.data.AppState
import com.centralhex.jarvis.data.AutomationRule
import com.centralhex.jarvis.data.ChatMessage
import com.centralhex.jarvis.data.JarvisSettings
import com.centralhex.jarvis.data.LocalStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class JarvisViewModel(application: Application) : AndroidViewModel(application) {

    private val store = LocalStore(application)
    private val ai = AiClient()
    private val device = DeviceActions(application)
    private val reminders = ReminderScheduler(application)
    private val router = CommandRouter(device, reminders, store)

    private val _state = MutableStateFlow(store.load())
    val state: StateFlow<AppState> = _state

    private val _isThinking = MutableStateFlow(false)
    val isThinking: StateFlow<Boolean> = _isThinking

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening

    private var voice: VoiceManager? = null

    init {
        if (_state.value.history.isEmpty()) {
            addMessage(ChatMessage(fromUser = false, text = "Bonjour. JARVIS est opérationnel. Que puis-je faire pour toi ?"))
        }
        voice = VoiceManager(
            context = application,
            onResult = { text -> sendMessage(text) },
            onListeningChange = { listening ->
                _isListening.value = listening
                WakeWordService.foregroundUiListening = listening
            },
            onError = { msg -> addMessage(ChatMessage(fromUser = false, text = msg)) }
        )

        if (_state.value.settings.wakeWordEnabled) WakeWordService.start(application)

        // Si le service d'écoute a ajouté des échanges pendant que l'appli était fermée, on les récupère.
        viewModelScope.launch {
            kotlinx.coroutines.delay(300)
            val fresh = store.load()
            if (fresh.history.size != _state.value.history.size) _state.value = fresh
        }
    }

    fun toggleListening() {
        if (_isListening.value) voice?.stopListening() else voice?.startListening()
    }

    /** Bouton micro : si la voix hors ligne est active, c'est elle qui écoute ; sinon l'ancienne méthode. */
    fun micPressed() {
        if (WakeWordService.activate(null) && WakeWordService.engineActive) return
        toggleListening()
    }

    /** À l'ouverture de l'appli, le micro s'ouvre tout seul (plus besoin de toucher le bouton). */
    fun autoMic() {
        val ctx = getApplication<Application>()
        val micOk = androidx.core.content.ContextCompat.checkSelfPermission(
            ctx, android.Manifest.permission.RECORD_AUDIO
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        if (!micOk) return
        if (WakeWordService.engineActive) { WakeWordService.activate(null); return }
        if (!_isListening.value && !_isThinking.value) voice?.startListening()
    }

    /** Relance le service d'écoute s'il est activé dans les réglages mais éteint. */
    fun ensureService() {
        if (_state.value.settings.wakeWordEnabled && !WakeWordService.isRunning) WakeWordService.start(getApplication())
    }

    fun sendMessage(text: String) {
        if (text.isBlank()) return
        addMessage(ChatMessage(fromUser = true, text = text))
        logActivity(text)

        when (val result = router.route(text, _state.value.rules)) {
            is RouteResult.LocalReply -> reply(result.text)
            is RouteResult.AskAi -> askAi()
            is RouteResult.StopSpeaking -> voice?.stopSpeaking()
        }
    }

    private fun askAi() {
        _isThinking.value = true
        viewModelScope.launch {
            val result = ai.ask(_state.value.history, _state.value.settings)
            _isThinking.value = false
            result.fold(
                onSuccess = { reply(it) },
                onFailure = { reply(it.message ?: "Je n'ai pas pu répondre, réessaie.") }
            )
        }
    }

    private fun reply(text: String) {
        addMessage(ChatMessage(fromUser = false, text = text))
        if (_state.value.settings.autoSpeak) voice?.speak(text)
    }

    private fun addMessage(message: ChatMessage) {
        _state.update { it.copy(history = it.history + message) }
        persist()
    }

    fun updateSettings(settings: JarvisSettings) {
        val wasEnabled = _state.value.settings.wakeWordEnabled
        _state.update { it.copy(settings = settings) }
        persist()
        if (settings.wakeWordEnabled && !wasEnabled) WakeWordService.start(getApplication<Application>())
        if (!settings.wakeWordEnabled && wasEnabled) WakeWordService.stop(getApplication<Application>())
    }

    fun addRule(rule: AutomationRule) {
        _state.update { it.copy(rules = it.rules + rule) }
        persist()
    }

    fun deleteRule(id: Long) {
        _state.update { it.copy(rules = it.rules.filterNot { r -> r.id == id }) }
        persist()
    }

    fun clearHistory() {
        _state.update { it.copy(history = emptyList()) }
        persist()
    }

    private fun logActivity(text: String) {
        val label = text.trim().replaceFirstChar { it.uppercase() }.take(48)
        _state.update { it.copy(activityLog = (it.activityLog + ActivityEntry(label = label)).takeLast(20)) }
        persist()
    }

    /** Recharge depuis le disque : utile après une action faite par l'écran de réveil ou le service. */
    fun refreshFromDisk() {
        val fresh = store.load()
        if (fresh != _state.value) _state.value = fresh
    }

    private fun persist() {
        store.save(_state.value)
    }

    override fun onCleared() {
        super.onCleared()
        voice?.destroy()
    }
}
