package com.centralhex.jarvis.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.centralhex.jarvis.core.DeviceActions
import com.centralhex.jarvis.data.JarvisSettings

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    settings: JarvisSettings,
    onSave: (JarvisSettings) -> Unit,
    onOpenRules: () -> Unit,
    onBack: () -> Unit
) {
    var apiKey by remember { mutableStateOf(settings.aiApiKey) }
    var baseUrl by remember { mutableStateOf(settings.aiBaseUrl) }
    var model by remember { mutableStateOf(settings.aiModel) }
    var autoSpeak by remember { mutableStateOf(settings.autoSpeak) }
    var wakeWord by remember { mutableStateOf(settings.wakeWordEnabled) }
    var darkTheme by remember { mutableStateOf(settings.darkTheme) }
    var showKey by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val device = remember { DeviceActions(context) }
    var adminActive by remember { mutableStateOf(device.isDeviceAdminActive()) }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("Réglages") },
            navigationIcon = {
                IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Retour") }
            }
        )
    }) { padding ->
        Column(
            Modifier
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Intelligence artificielle", style = MaterialTheme.typography.titleLarge)
            Text(
                "Colle une clé gratuite d'un fournisseur compatible OpenAI, par exemple Groq " +
                    "(console.groq.com) ou OpenRouter (openrouter.ai/keys). Elle reste uniquement sur ce téléphone.",
                style = MaterialTheme.typography.bodySmall
            )

            OutlinedTextField(
                value = apiKey,
                onValueChange = { apiKey = it },
                label = { Text("Clé API") },
                singleLine = true,
                visualTransformation = if (showKey) androidx.compose.ui.text.input.VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    TextButton(onClick = { showKey = !showKey }) { Text(if (showKey) "Masquer" else "Voir") }
                },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = baseUrl,
                onValueChange = { baseUrl = it },
                label = { Text("Adresse de l'API") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = model,
                onValueChange = { model = it },
                label = { Text("Modèle") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Divider()
            Text("Voix", style = MaterialTheme.typography.titleLarge)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = autoSpeak, onCheckedChange = { autoSpeak = it })
                Spacer(Modifier.width(10.dp))
                Text("JARVIS répond aussi à voix haute")
            }

            Divider()
            Text("Apparence", style = MaterialTheme.typography.titleLarge)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = darkTheme, onCheckedChange = { darkTheme = it })
                Spacer(Modifier.width(10.dp))
                Text(if (darkTheme) "Thème sombre" else "Thème clair")
            }

            Divider()
            Text("Mot de réveil", style = MaterialTheme.typography.titleLarge)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = wakeWord, onCheckedChange = { wakeWord = it })
                Spacer(Modifier.width(10.dp))
                Text("JARVIS écoute en permanence, même écran éteint")
            }
            Text(
                "Dis « JARVIS » puis ta demande, sans rien toucher. Une notification discrète " +
                    "reste affichée pendant qu'il écoute (obligatoire sur Android), et ça consomme " +
                    "un peu de batterie. Sur certains téléphones, désactive l'optimisation de " +
                    "batterie pour JARVIS pour que ça marche aussi écran éteint.",
                style = MaterialTheme.typography.bodySmall
            )

            Divider()
            Text("Verrouillage à distance", style = MaterialTheme.typography.titleLarge)
            Text(
                if (adminActive) "✅ Activé : tu peux dire « verrouille l'écran »."
                else "Nécessaire uniquement pour que JARVIS puisse verrouiller l'écran sur demande.",
                style = MaterialTheme.typography.bodySmall
            )
            OutlinedButton(
                onClick = {
                    if (!adminActive) context.startActivity(device.requestDeviceAdmin())
                },
                enabled = !adminActive,
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (adminActive) "Déjà activé" else "Activer le verrouillage à distance") }

            Divider()
            OutlinedButton(onClick = onOpenRules, modifier = Modifier.fillMaxWidth()) {
                Text("Gérer les automatisations")
            }

            Button(
                onClick = { onSave(JarvisSettings(apiKey.trim(), baseUrl.trim(), model.trim(), autoSpeak, wakeWord, darkTheme)) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Enregistrer") }

            Text(
                "✦ Propulsé par CENTRAL-HEX 🇬🇳 ✦",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 4.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    }
}
