package com.centralhex.jarvis.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.centralhex.jarvis.core.DeviceActions
import com.centralhex.jarvis.data.JarvisSettings

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    settings: JarvisSettings,
    onSave: (JarvisSettings) -> Unit,
    onOpenRules: () -> Unit,
    onBack: () -> Unit
) {
    var apiKey by remember { mutableStateOf(settings.aiApiKey) }
    var baseUrl by remember { mutableStateOf(settings.aiBaseUrl) }
    var model by remember { mutableStateOf(settings.aiModel) }
    var autoSpeak by remember { mutableStateOf(settings.autoSpeak) }
    var wakeWord by remember { mutableStateOf(settings.wakeWordEnabled) }
    var showKey by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val device = remember { DeviceActions(context) }
    var adminActive by remember { mutableStateOf(device.isDeviceAdminActive()) }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("Réglages") },
            navigationIcon = {
                IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Retour") }
            }
        )
    }) { padding ->
        Column(
            Modifier
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Intelligence artificielle", style = MaterialTheme.typography.titleLarge)
            Text(
                "Colle une clé gratuite d'un fournisseur compatible OpenAI, par exemple Groq " +
                    "(console.groq.com) ou OpenRouter (openrouter.ai/keys). Elle reste uniquement sur ce téléphone.",
                style = MaterialTheme.typography.bodySmall
            )

            OutlinedTextField(
                value = apiKey,
                onValueChange = { apiKey = it },
                label = { Text("Clé API") },
                singleLine = true,
                visualTransformation = if (showKey) androidx.compose.ui.text.input.VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    TextButton(onClick = { showKey = !showKey }) { Text(if (showKey) "Masquer" else "Voir") }
                },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = baseUrl,
                onValueChange = { baseUrl = it },
                label = { Text("Adresse de l'API") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = model,
                onValueChange = { model = it },
                label = { Text("Modèle") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Divider()
            Text("Voix", style = MaterialTheme.typography.titleLarge)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = autoSpeak, onCheckedChange = { autoSpeak = it })
                Spacer(Modifier.width(10.dp))
                Text("JARVIS répond aussi à voix haute")
            }

            Divider()
            Text("Mot de réveil", style = MaterialTheme.typography.titleLarge)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = wakeWord, onCheckedChange = { wakeWord = it })
                Spacer(Modifier.width(10.dp))
                Text("JARVIS écoute en permanence, même écran éteint")
            }
            Text(
                "Dis « JARVIS » puis ta demande, sans rien toucher. Une notification discrète " +
                    "reste affichée pendant qu'il écoute (obligatoire sur Android), et ça consomme " +
                    "un peu de batterie. Sur certains téléphones, désactive l'optimisation de " +
                    "batterie pour JARVIS pour que ça marche aussi écran éteint.",
                style = MaterialTheme.typography.bodySmall
            )

            Divider()
            Text("Verrouillage à distance", style = MaterialTheme.typography.titleLarge)
            Text(
                if (adminActive) "✅ Activé : tu peux dire « verrouille l'écran »."
                else "Nécessaire uniquement pour que JARVIS puisse verrouiller l'écran sur demande.",
                style = MaterialTheme.typography.bodySmall
            )
            OutlinedButton(
                onClick = {
                    if (!adminActive) context.startActivity(device.requestDeviceAdmin())
                },
                enabled = !adminActive,
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (adminActive) "Déjà activé" else "Activer le verrouillage à distance") }

            Divider()
            Text("Réveil « JARVIS » (écran éteint)", style = MaterialTheme.typography.titleLarge)
            Text(
                if (com.centralhex.jarvis.core.WakeWordService.isRunning) "✅ L'écoute est active (notification « JARVIS veille »)."
                else "❌ L'écoute n'est pas active. Active « Mot JARVIS » sur l'accueil.",
                style = MaterialTheme.typography.bodySmall
            )
            OutlinedButton(
                onClick = { device.requestIgnoreBatteryOptimizations() },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Empêcher la mise en veille de JARVIS") }
            Text(
                "Pour qu'il lance des applis, la caméra ou YouTube quand tu lui parles hors de l'appli, " +
                    "autorise-le à s'afficher par-dessus les autres applis.",
                style = MaterialTheme.typography.bodySmall
            )
            OutlinedButton(
                onClick = { device.requestOverlayPermission() },
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (device.canDrawOverlays()) "✅ Affichage par-dessus les autres applis : autorisé" else "Autoriser l'affichage par-dessus les autres applis") }

            Divider()
            Text("Permissions (SMS, micro, plein écran…)", style = MaterialTheme.typography.titleLarge)
            Text(
                "Si l'envoi de SMS est bloqué : ouvre les paramètres de l'appli, touche le menu ⋮ en haut à droite, " +
                    "choisis « Autoriser les paramètres restreints », puis Autorisations ▸ SMS ▸ Autoriser.",
                style = MaterialTheme.typography.bodySmall
            )
            OutlinedButton(
                onClick = { device.openAppSettings() },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Ouvrir les paramètres de JARVIS") }

            Divider()
            OutlinedButton(onClick = onOpenRules, modifier = Modifier.fillMaxWidth()) {
                Text("Gérer les automatisations")
            }

            Button(
                onClick = { onSave(settings.copy(aiApiKey = apiKey.trim(), aiBaseUrl = baseUrl.trim(), aiModel = model.trim(), autoSpeak = autoSpeak, wakeWordEnabled = wakeWord)) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Enregistrer") }

            Text(
                "✦ Propulsé par CENTRAL-HEX 🇬🇳 ✦",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 4.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    }
}
