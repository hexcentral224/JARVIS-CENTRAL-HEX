package com.centralhex.jarvis.core

import android.app.KeyguardManager
import android.app.NotificationManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.telephony.SmsManager
import android.view.KeyEvent
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Tout ce que JARVIS peut faire sur le téléphone. Chaque action vérifie la
 * permission avant d'agir ; si elle manque, on bascule sur l'action "manuelle"
 * (ouvrir l'appli Téléphone/Messages déjà pré-remplie) plutôt que d'échouer.
 */
class DeviceActions(private val context: Context) {

    private fun has(perm: String) =
        ContextCompat.checkSelfPermission(context, perm) == PackageManager.PERMISSION_GRANTED

    /** Liste des applications que l'utilisateur peut ouvrir (nom affiché -> nom de paquet). */
    fun listInstalledApps(): Map<String, String> {
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val pm = context.packageManager
        return pm.queryIntentActivities(intent, 0).associate { info ->
            info.loadLabel(pm).toString() to info.activityInfo.packageName
        }
    }

    /** Cherche l'appli dont le nom ressemble le plus à [query] et l'ouvre. */
    fun openApp(query: String): String {
        val apps = listInstalledApps()
        val q = normalize(query)
        val match = apps.entries.firstOrNull { normalize(it.key) == q }
            ?: apps.entries.firstOrNull { normalize(it.key).contains(q) || q.contains(normalize(it.key)) }
            ?: return "Je ne trouve pas d'application qui s'appelle « $query »."
        val launchIntent = context.packageManager.getLaunchIntentForPackage(match.value)
        return if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            "J'ouvre ${match.key}."
        } else "Je n'arrive pas à ouvrir ${match.key}."
    }

    /** Cherche un numéro dans les contacts à partir d'un nom. */
    /** "ma mère" doit aussi trouver "Maman", "Mama"… */
    private fun contactAliases(name: String): List<String> {
        val full = normalize(name)
        val bare = full.replace(Regex("^(ma|mon|mes|le|la|l)\\s+"), "").trim()
        val extra = when (bare) {
            "mere", "maman", "mama", "mom", "ma maman" -> listOf("maman", "mama", "mere", "mom")
            "pere", "papa", "dad" -> listOf("papa", "pere", "dad")
            "soeur", "sis" -> listOf("soeur", "sis")
            "frere", "bro" -> listOf("frere", "bro")
            else -> emptyList()
        }
        return (listOf(full, bare) + extra).filter { it.isNotBlank() }.distinct()
    }

    fun findContactNumber(name: String): String? {
        if (!has(android.Manifest.permission.READ_CONTACTS)) return null
        val contacts = mutableListOf<Pair<String, String>>()
        context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null
        )?.use {
            while (it.moveToNext()) {
                val n = it.getString(0) ?: continue
                val num = it.getString(1) ?: continue
                contacts += normalize(n) to num
            }
        } ?: return null
        for (alias in contactAliases(name)) {
            contacts.firstOrNull { it.first == alias }?.let { return it.second }
            contacts.firstOrNull { it.first.contains(alias) }?.let { return it.second }
        }
        return null
    }

    /** Appelle un numéro (ou un nom de contact). */
    @android.annotation.SuppressLint("MissingPermission")
    fun call(target: String): String {
        val number = if (target.any(Char::isDigit) && target.count(Char::isDigit) >= 6) target
        else findContactNumber(target) ?: return "Je n'ai pas trouvé « $target » dans tes contacts."

        if (has(android.Manifest.permission.CALL_PHONE)) {
            // TelecomManager : Android autorise ça même quand JARVIS est en arrière-plan (contrairement à startActivity).
            try {
                val tm = context.getSystemService(Context.TELECOM_SERVICE) as android.telecom.TelecomManager
                tm.placeCall(Uri.fromParts("tel", number, null), android.os.Bundle())
                return "J'appelle $target."
            } catch (e: Exception) { /* on essaie la méthode classique ci-dessous */ }
            if (tryStart(Intent(Intent.ACTION_CALL, Uri.parse("tel:$number")))) return "J'appelle $target."
        }
        tryStart(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")))
        return "Je n'ai pas la permission d'appeler directement, j'ouvre le composeur pour $number."
    }

    @Suppress("DEPRECATION")
    fun sendSms(target: String, body: String): String {
        val number = if (target.any(Char::isDigit) && target.count(Char::isDigit) >= 6) target
        else findContactNumber(target) ?: return "Je n'ai pas trouvé « $target » dans tes contacts."

        if (body.isBlank()) {
            return if (tryStart(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)))
                "J'ouvre Messages pour $target." else "Je n'ai pas trouvé d'application de messages."
        }

        if (has(android.Manifest.permission.SEND_SMS)) {
            return try {
                val sms: SmsManager = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S)
                    context.getSystemService(SmsManager::class.java)
                else SmsManager.getDefault()
                val parts = sms.divideMessage(body)
                if (parts.size > 1) sms.sendMultipartTextMessage(number, null, parts, null, null)
                else sms.sendTextMessage(number, null, body, null, null)
                "SMS envoyé à $target."
            } catch (e: Exception) {
                openSmsCompose(number, body)
                "L'envoi direct a échoué (${e.message}). J'ai ouvert Messages : appuie sur envoyer."
            }
        }

        // Permission SMS absente (souvent bloquée par Android pour les applis installées hors Play Store)
        openSmsCompose(number, body)
        return "Android bloque l'envoi direct de SMS pour JARVIS, j'ai ouvert Messages : appuie sur envoyer. " +
            "Pour l'activer : Réglages ▸ Ouvrir les paramètres de l'appli ▸ menu ⋮ ▸ Autoriser les paramètres restreints, puis Autorisations ▸ SMS."
    }

    private fun openSmsCompose(number: String, body: String) {
        tryStart(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number")).putExtra("sms_body", body).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** Lance une activité sans planter si aucune appli ne sait la gérer. */
    private fun tryStart(intent: Intent): Boolean = try {
        context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
    } catch (e: Exception) { false }

    /** Demande à Android de ne pas endormir JARVIS : indispensable pour que « JARVIS » marche écran éteint. */
    @android.annotation.SuppressLint("BatteryLife")
    fun requestIgnoreBatteryOptimizations(): String {
        val pm = context.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
        if (pm.isIgnoringBatteryOptimizations(context.packageName)) return "C'est déjà réglé : JARVIS n'est pas limité par la batterie."
        val direct = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${context.packageName}"))
        if (tryStart(direct)) return "Accepte pour que JARVIS reste actif écran éteint."
        return if (tryStart(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))) "Choisis JARVIS puis « Ne pas optimiser »." else "Je n'ai pas pu ouvrir ce réglage."
    }

    fun canDrawOverlays(): Boolean = Settings.canDrawOverlays(context)

    /**
     * « Afficher par-dessus les autres applis » : permet à JARVIS de lancer une appli, la caméra, YouTube…
     * quand tu lui parles alors qu'il est en arrière-plan (Android bloque ça sinon).
     */
    fun requestOverlayPermission(): String {
        if (Settings.canDrawOverlays(context)) return "C'est déjà autorisé."
        val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))
        return if (tryStart(i)) "Active « Autoriser l'affichage par-dessus d'autres applis » pour JARVIS." else "Je n'ai pas pu ouvrir ce réglage."
    }

    /** Ouvre l'écran "Infos de l'appli" de JARVIS (permissions, paramètres restreints, batterie). */
    fun openAppSettings(): String {
        val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
        return if (tryStart(i)) "J'ouvre les paramètres de JARVIS." else "Je n'ai pas pu ouvrir les paramètres."
    }

    // ───────────── Musique, vidéo, galerie ─────────────

    /** "joue Burna Boy" : demande à l'appli de musique (Spotify, YouTube Music…) de chercher et lancer. */
    fun playMusic(query: String): String {
        val q = query.trim()
        val intent = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
            putExtra(android.app.SearchManager.QUERY, q)
            putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
        }
        if (tryStart(intent)) return if (q.isEmpty()) "Je lance la musique." else "Je lance « $q »."
        if (q.isEmpty()) return mediaControl("play_pause")
        return searchVideo("$q", musicFallback = true)
    }

    /** "mets une vidéo de ..." : recherche dans YouTube (appli si installée, sinon navigateur). */
    fun searchVideo(query: String, musicFallback: Boolean = false): String {
        val q = query.trim()
        if (q.isEmpty()) return openApp("YouTube")
        val yt = Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube").putExtra("query", q)
        if (tryStart(yt)) return if (musicFallback) "Pas d'appli de musique trouvée, je cherche « $q » sur YouTube." else "Je cherche « $q » sur YouTube."
        val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + java.net.URLEncoder.encode(q, "UTF-8")))
        return if (tryStart(web)) "Je cherche « $q » sur YouTube." else "Je n'ai pas pu ouvrir YouTube."
    }

    fun openGallery(): String {
        val gallery = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY)
        if (tryStart(gallery)) return "J'ouvre ta galerie."
        val images = Intent(Intent.ACTION_VIEW, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        if (tryStart(images)) return "J'ouvre tes photos."
        return openApp("Galerie")
    }

    /** Ouvre l'horloge pour régler une alarme (l'OS gère le reste, aucune permission requise). */
    fun setAlarm(hour: Int, minute: Int, label: String = "JARVIS"): String {
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, label)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return if (intent.resolveActivity(context.packageManager) != null) {
            context.startActivity(intent)
            "Alarme réglée à %02d:%02d.".format(hour, minute)
        } else "Je ne trouve pas d'application d'horloge sur ce téléphone."
    }

    // ── Tout ce qui suit fonctionne sans connexion internet ──

    fun currentTime(): String {
        val f = SimpleDateFormat("HH:mm", Locale.FRENCH)
        return "Il est ${f.format(Date())}."
    }

    fun currentDate(): String {
        val f = SimpleDateFormat("EEEE d MMMM yyyy", Locale.FRENCH)
        return "Nous sommes le ${f.format(Date())}."
    }

    data class Battery(val percent: Int, val charging: Boolean)

    fun batteryInfo(): Battery {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        return Battery(bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY), bm.isCharging)
    }

    fun isWifiConnected(): Boolean {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            caps?.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) == true
        } catch (e: Exception) { false }
    }

    fun isMobileDataConnected(): Boolean {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            caps?.hasTransport(android.net.NetworkCapabilities.TRANSPORT_CELLULAR) == true
        } catch (e: Exception) { false }
    }

    fun batteryStatus(): String {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val charging = bm.isCharging
        return "Batterie à $level %${if (charging) ", en charge" else ""}."
    }

    private var torchOn = false
    fun toggleFlashlight(on: Boolean): String {
        return try {
            val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val camId = cm.cameraIdList.firstOrNull() ?: return "Aucune lampe torche détectée sur cet appareil."
            cm.setTorchMode(camId, on)
            torchOn = on
            if (on) "Lampe torche allumée." else "Lampe torche éteinte."
        } catch (e: Exception) {
            "Je n'ai pas pu ${if (on) "allumer" else "éteindre"} la lampe torche."
        }
    }

    fun adjustVolume(up: Boolean): String {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val direction = if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
        return if (up) "Je monte le volume." else "Je baisse le volume."
    }

    /** Android empêche d'activer le Wi-Fi/Bluetooth directement depuis une appli : on ouvre le bon écran. */
    fun openSystemSettings(target: String): String {
        val action = when (target) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "J'ouvre les réglages $target."
    }

    /** Ouvre l'appareil photo. */
    fun openCamera(): String {
        val intent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return if (intent.resolveActivity(context.packageManager) != null) {
            context.startActivity(intent); "J'ouvre l'appareil photo."
        } else "Aucune application appareil photo trouvée."
    }

    /** Ouvre l'appli de cartes (plan centré sur la position actuelle, gérée par l'appli elle-même). */
    fun openMap(): String {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return if (intent.resolveActivity(context.packageManager) != null) {
            context.startActivity(intent); "J'ouvre la carte."
        } else "Aucune application de cartes trouvée."
    }

    /** Lecture / pause / piste suivante / précédente — fonctionne avec le lecteur de musique déjà actif. */
    fun mediaControl(action: String): String {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val code = when (action) {
            "play_pause" -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "prev" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            else -> return "Commande média inconnue."
        }
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return when (action) {
            "play_pause" -> "C'est fait."
            "next" -> "Piste suivante."
            else -> "Piste précédente."
        }
    }

    private fun hasDndAccess(): Boolean {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        return nm.isNotificationPolicyAccessGranted
    }

    /** Mode sonore : silencieux / vibreur / normal. Demande une autorisation à accorder une seule fois. */
    fun setRingerMode(mode: String): String {
        if (!hasDndAccess()) {
            context.startActivity(
                Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return "J'ai besoin d'une autorisation pour changer le son : active JARVIS dans l'écran qui vient de s'ouvrir, puis redemande-le-moi."
        }
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.ringerMode = when (mode) {
            "silencieux" -> AudioManager.RINGER_MODE_SILENT
            "vibreur" -> AudioManager.RINGER_MODE_VIBRATE
            else -> AudioManager.RINGER_MODE_NORMAL
        }
        return when (mode) {
            "silencieux" -> "Mode silencieux activé."
            "vibreur" -> "Mode vibreur activé."
            else -> "Son normal rétabli."
        }
    }

    /** Ne pas déranger : coupe aussi les notifications visuelles, pas seulement le son. */
    fun setDoNotDisturb(on: Boolean): String {
        if (!hasDndAccess()) {
            context.startActivity(
                Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return "J'ai besoin d'une autorisation pour ça : active JARVIS dans l'écran qui vient de s'ouvrir, puis redemande-le-moi."
        }
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.setInterruptionFilter(if (on) NotificationManager.INTERRUPTION_FILTER_NONE else NotificationManager.INTERRUPTION_FILTER_ALL)
        return if (on) "Mode Ne pas déranger activé." else "Mode Ne pas déranger désactivé."
    }

    /** Android interdit d'activer le mode avion directement depuis une appli : on ouvre l'écran dédié. */
    fun openAirplaneModeSettings(): String {
        context.startActivity(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "J'ouvre les réglages du mode avion."
    }

    private fun adminComponent() = ComponentName(context, JarvisDeviceAdminReceiver::class.java)

    fun isDeviceAdminActive(): Boolean {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        return dpm.isAdminActive(adminComponent())
    }

    fun requestDeviceAdmin(): Intent =
        Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Autorise JARVIS à verrouiller l'écran quand tu le lui demandes.")
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent())
        }

    /** Verrouille l'écran. Nécessite d'avoir activé "Verrouillage à distance" dans Réglages une fois. */
    fun lockScreen(): String {
        if (!isDeviceAdminActive()) return "Active d'abord « Verrouillage à distance » dans Réglages pour que je puisse verrouiller l'écran."
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        dpm.lockNow()
        return "Écran verrouillé."
    }

    fun isScreenLocked(): Boolean {
        val km = context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        return km.isKeyguardLocked
    }

    private fun normalize(s: String) = s.lowercase()
        .replace("é", "e").replace("è", "e").replace("ê", "e")
        .replace("à", "a").replace("ù", "u").replace("ô", "o")
        .trim()
}
