package com.centralhex.jarvis.core

import android.app.KeyguardManager
import android.app.NotificationManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.telephony.SmsManager
import android.view.KeyEvent
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Tout ce que JARVIS peut faire sur le téléphone. Chaque action vérifie la
 * permission avant d'agir ; si elle manque, on bascule sur l'action "manuelle"
 * (ouvrir l'appli Téléphone/Messages déjà pré-remplie) plutôt que d'échouer.
 */
class DeviceActions(private val context: Context) {

    private fun has(perm: String) =
        ContextCompat.checkSelfPermission(context, perm) == PackageManager.PERMISSION_GRANTED

    /** Liste des applications que l'utilisateur peut ouvrir (nom affiché -> nom de paquet). */
    fun listInstalledApps(): Map<String, String> {
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val pm = context.packageManager
        return pm.queryIntentActivities(intent, 0).associate { info ->
            info.loadLabel(pm).toString() to info.activityInfo.packageName
        }
    }

    /** Cherche l'appli dont le nom ressemble le plus à [query] et l'ouvre. */
    fun openApp(query: String): String {
        val apps = listInstalledApps()
        val q = normalize(query)
        val match = apps.entries.firstOrNull { normalize(it.key) == q }
            ?: apps.entries.firstOrNull { normalize(it.key).contains(q) || q.contains(normalize(it.key)) }
            ?: return "Je ne trouve pas d'application qui s'appelle « $query »."
        val launchIntent = context.packageManager.getLaunchIntentForPackage(match.value)
        return if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            "J'ouvre ${match.key}."
        } else "Je n'arrive pas à ouvrir ${match.key}."
    }

    /** Cherche un numéro dans les contacts à partir d'un nom. */
    fun findContactNumber(name: String): String? {
        if (!has(android.Manifest.permission.READ_CONTACTS)) return null
        val resolver = context.contentResolver
        val cursor = resolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null
        ) ?: return null
        val target = normalize(name)
        cursor.use {
            while (it.moveToNext()) {
                val displayName = it.getString(0) ?: continue
                if (normalize(displayName).contains(target)) {
                    return it.getString(1)
                }
            }
        }
        return null
    }

    /** Appelle un numéro (ou un nom de contact). */
    fun call(target: String): String {
        val number = if (target.any(Char::isDigit) && target.count(Char::isDigit) >= 6) target
        else findContactNumber(target) ?: return "Je n'ai pas trouvé « $target » dans tes contacts."

        return if (has(android.Manifest.permission.CALL_PHONE)) {
            context.startActivity(
                Intent(Intent.ACTION_CALL, Uri.parse("tel:$number")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            "J'appelle $number."
        } else {
            context.startActivity(
                Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            "Je n'ai pas la permission d'appeler directement, j'ouvre le composeur pour $number."
        }
    }

    /** Envoie un SMS (ou ouvre l'appli Messages pré-remplie si la permission manque). */
    fun sendSms(target: String, body: String): String {
        val number = if (target.any(Char::isDigit) && target.count(Char::isDigit) >= 6) target
        else findContactNumber(target) ?: return "Je n'ai pas trouvé « $target » dans tes contacts."

        return if (has(android.Manifest.permission.SEND_SMS)) {
            try {
                @Suppress("DEPRECATION")
                val sms = SmsManager.getDefault()
                sms.sendTextMessage(number, null, body, null, null)
                "SMS envoyé à $number."
            } catch (e: Exception) {
                "Je n'ai pas pu envoyer le SMS : ${e.message}"
            }
        } else {
            val uri = Uri.parse("smsto:$number")
            context.startActivity(
                Intent(Intent.ACTION_SENDTO, uri).putExtra("sms_body", body).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            "Je n'ai pas la permission d'envoyer directement, j'ouvre Messages pour $number."
        }
    }

    /** Ouvre l'horloge pour régler une alarme (l'OS gère le reste, aucune permission requise). */
    fun setAlarm(hour: Int, minute: Int, label: String = "JARVIS"): String {
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, label)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return if (intent.resolveActivity(context.packageManager) != null) {
            context.startActivity(intent)
            "Alarme réglée à %02d:%02d.".format(hour, minute)
        } else "Je ne trouve pas d'application d'horloge sur ce téléphone."
    }

    // ── Tout ce qui suit fonctionne sans connexion internet ──

    fun currentTime(): String {
        val f = SimpleDateFormat("HH:mm", Locale.FRENCH)
        return "Il est ${f.format(Date())}."
    }

    fun currentDate(): String {
        val f = SimpleDateFormat("EEEE d MMMM yyyy", Locale.FRENCH)
        return "Nous sommes le ${f.format(Date())}."
    }

    data class Battery(val percent: Int, val charging: Boolean)

    fun batteryInfo(): Battery {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        return Battery(bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY), bm.isCharging)
    }

    fun isWifiConnected(): Boolean {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            caps?.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) == true
        } catch (e: Exception) { false }
    }

    fun isMobileDataConnected(): Boolean {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            caps?.hasTransport(android.net.NetworkCapabilities.TRANSPORT_CELLULAR) == true
        } catch (e: Exception) { false }
    }

    fun batteryStatus(): String {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val charging = bm.isCharging
        return "Batterie à $level %${if (charging) ", en charge" else ""}."
    }

    private var torchOn = false
    fun toggleFlashlight(on: Boolean): String {
        return try {
            val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val camId = cm.cameraIdList.firstOrNull() ?: return "Aucune lampe torche détectée sur cet appareil."
            cm.setTorchMode(camId, on)
            torchOn = on
            if (on) "Lampe torche allumée." else "Lampe torche éteinte."
        } catch (e: Exception) {
            "Je n'ai pas pu ${if (on) "allumer" else "éteindre"} la lampe torche."
        }
    }

    fun adjustVolume(up: Boolean): String {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val direction = if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
        return if (up) "Je monte le volume." else "Je baisse le volume."
    }

    /** Android empêche d'activer le Wi-Fi/Bluetooth directement depuis une appli : on ouvre le bon écran. */
    fun openSystemSettings(target: String): String {
        val action = when (target) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "J'ouvre les réglages $target."
    }

    /** Ouvre l'appareil photo. */
    fun openCamera(): String {
        val intent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return if (intent.resolveActivity(context.packageManager) != null) {
            context.startActivity(intent); "J'ouvre l'appareil photo."
        } else "Aucune application appareil photo trouvée."
    }

    /** Ouvre l'appli de cartes (plan centré sur la position actuelle, gérée par l'appli elle-même). */
    fun openMap(): String {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return if (intent.resolveActivity(context.packageManager) != null) {
            context.startActivity(intent); "J'ouvre la carte."
        } else "Aucune application de cartes trouvée."
    }

    /** Lecture / pause / piste suivante / précédente — fonctionne avec le lecteur de musique déjà actif. */
    fun mediaControl(action: String): String {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val code = when (action) {
            "play_pause" -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "prev" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            else -> return "Commande média inconnue."
        }
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return when (action) {
            "play_pause" -> "C'est fait."
            "next" -> "Piste suivante."
            else -> "Piste précédente."
        }
    }

    private fun hasDndAccess(): Boolean {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        return nm.isNotificationPolicyAccessGranted
    }

    /** Mode sonore : silencieux / vibreur / normal. Demande une autorisation à accorder une seule fois. */
    fun setRingerMode(mode: String): String {
        if (!hasDndAccess()) {
            context.startActivity(
                Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return "J'ai besoin d'une autorisation pour changer le son : active JARVIS dans l'écran qui vient de s'ouvrir, puis redemande-le-moi."
        }
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.ringerMode = when (mode) {
            "silencieux" -> AudioManager.RINGER_MODE_SILENT
            "vibreur" -> AudioManager.RINGER_MODE_VIBRATE
            else -> AudioManager.RINGER_MODE_NORMAL
        }
        return when (mode) {
            "silencieux" -> "Mode silencieux activé."
            "vibreur" -> "Mode vibreur activé."
            else -> "Son normal rétabli."
        }
    }

    /** Ne pas déranger : coupe aussi les notifications visuelles, pas seulement le son. */
    fun setDoNotDisturb(on: Boolean): String {
        if (!hasDndAccess()) {
            context.startActivity(
                Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return "J'ai besoin d'une autorisation pour ça : active JARVIS dans l'écran qui vient de s'ouvrir, puis redemande-le-moi."
        }
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.setInterruptionFilter(if (on) NotificationManager.INTERRUPTION_FILTER_NONE else NotificationManager.INTERRUPTION_FILTER_ALL)
        return if (on) "Mode Ne pas déranger activé." else "Mode Ne pas déranger désactivé."
    }

    /** Android interdit d'activer le mode avion directement depuis une appli : on ouvre l'écran dédié. */
    fun openAirplaneModeSettings(): String {
        context.startActivity(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "J'ouvre les réglages du mode avion."
    }

    private fun adminComponent() = ComponentName(context, JarvisDeviceAdminReceiver::class.java)

    fun isDeviceAdminActive(): Boolean {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        return dpm.isAdminActive(adminComponent())
    }

    fun requestDeviceAdmin(): Intent =
        Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Autorise JARVIS à verrouiller l'écran quand tu le lui demandes.")
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent())
        }

    /** Verrouille l'écran. Nécessite d'avoir activé "Verrouillage à distance" dans Réglages une fois. */
    fun lockScreen(): String {
        if (!isDeviceAdminActive()) return "Active d'abord « Verrouillage à distance » dans Réglages pour que je puisse verrouiller l'écran."
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        dpm.lockNow()
        return "Écran verrouillé."
    }

    fun isScreenLocked(): Boolean {
        val km = context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        return km.isKeyguardLocked
    }

    private fun normalize(s: String) = s.lowercase()
        .replace("é", "e").replace("è", "e").replace("ê", "e")
        .replace("à", "a").replace("ù", "u").replace("ô", "o")
        .trim()
}
