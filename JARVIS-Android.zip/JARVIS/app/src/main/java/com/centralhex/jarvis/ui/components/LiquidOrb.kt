package com.centralhex.jarvis.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin

private data class OrbPalette(val c1: Color, val c2: Color, val c3: Color, val c4: Color, val c5: Color)

private fun paletteOf(s: OrbState) = when (s) {
    // repos : bulle irisée violet / rose / cyan / blanc (comme la vidéo)
    OrbState.IDLE -> OrbPalette(Color(0xFF241A8C), Color(0xFF7B3DF5), Color(0xFFE05CC8), Color(0xFF3DE8E0), Color(0xFFF4FBFF))
    OrbState.LISTENING -> OrbPalette(Color(0xFF6E0C2A), Color(0xFFFF3B5C), Color(0xFFFF8A4C), Color(0xFFFFC9A0), Color(0xFFFFF6EE))
    OrbState.THINKING -> OrbPalette(Color(0xFF5A3A00), Color(0xFFFFA81F), Color(0xFFFFD84D), Color(0xFFFFEFA8), Color(0xFFFFFBEA))
    OrbState.SPEAKING -> OrbPalette(Color(0xFF053A48), Color(0xFF14BFA0), Color(0xFF3DE8E0), Color(0xFFB4FFF0), Color(0xFFF2FFFC))
}

/** Contour d'une bulle qui se déforme : somme de vagues de fréquences différentes. */
private fun blobPath(cx: Float, cy: Float, r: Float, t: Float, amp: Float, seed: Float, stretch: Float): Path {
    val p = Path()
    val n = 96
    for (i in 0..n) {
        val a = i * 6.2831855f / n
        val k = 1f + amp * (
            0.050f * sin(2 * a + t + seed) +
                0.036f * sin(3 * a - 1.3f * t + seed * 2f) +
                0.022f * sin(5 * a + 1.9f * t + seed * 3f) +
                0.012f * sin(7 * a - 2.4f * t)
            )
        val x = cx + r * k * cos(a)
        val y = cy + r * k * sin(a) * stretch
        if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
    }
    p.close()
    return p
}

/**
 * La bulle liquide de JARVIS (grand écran d'accueil et écran de réveil) : elle se déforme en continu,
 * des reflets irisés glissent à l'intérieur, et elle change de couleur et de rythme selon l'état
 * (veille, écoute, réflexion, réponse).
 */
@Composable
fun ArcReactor(state: OrbState, diameter: Dp, modifier: Modifier = Modifier) {
    val target = paletteOf(state)
    val c1 by animateColorAsState(target.c1, tween(700), label = "c1")
    val c2 by animateColorAsState(target.c2, tween(700), label = "c2")
    val c3 by animateColorAsState(target.c3, tween(700), label = "c3")
    val c4 by animateColorAsState(target.c4, tween(700), label = "c4")
    val c5 by animateColorAsState(target.c5, tween(700), label = "c5")

    val speed = rememberUpdatedState(
        when (state) { OrbState.IDLE -> 1f; OrbState.THINKING -> 2.2f; OrbState.LISTENING -> 2.6f; OrbState.SPEAKING -> 3.2f }
    )
    val amp by animateFloatAsState(
        when (state) { OrbState.IDLE -> 1f; OrbState.THINKING -> 1.6f; OrbState.LISTENING -> 2.1f; OrbState.SPEAKING -> 1.9f },
        tween(700), label = "amp"
    )
    val speaking = state == OrbState.SPEAKING

    // horloge continue dont la vitesse change en douceur selon l'état
    var clock by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                if (last != 0L) clock += (now - last) / 1_000_000_000f * speed.value
                last = now
            }
        }
    }

    Canvas(modifier.size(diameter).blur(3.dp, BlurredEdgeTreatment.Unbounded)) {
        val t = clock
        val w = this.size.width
        val cx = w / 2f
        val cy = this.size.height / 2f
        val big = w / 2f
        val center = Offset(cx, cy)
        val talk = if (speaking) 1f + 0.25f * sin(t * 7f) else 1f
        val a = amp * talk
        val breath = 1f + 0.035f * sin(t * 1.3f)
        val stretch = 1.04f + 0.04f * sin(t * 0.9f)

        // lueur diffuse
        drawCircle(
            Brush.radialGradient(listOf(c2.copy(alpha = 0.38f), Color.Transparent), center = center, radius = big),
            radius = big, center = center
        )

        // corps de la bulle : la lumière se déplace dedans
        val main = blobPath(cx, cy, big * 0.70f * breath, t, a, 0f, stretch)
        val light = Offset(cx + big * 0.22f * sin(t * 0.8f), cy - big * 0.25f + big * 0.10f * cos(t * 1.1f))
        drawPath(
            main,
            Brush.radialGradient(
                0f to c5, 0.28f to c4, 0.55f to c3, 0.8f to c2, 1f to c1,
                center = light, radius = big * 0.95f
            )
        )

        // reflets irisés qui tournent à l'intérieur
        for (i in 0 until 3) {
            val sc = 0.62f - i * 0.15f
            val p = blobPath(cx, cy, big * 0.70f * sc * breath, t * (1.2f + i * 0.4f) + i * 2f, a * 1.2f, i * 1.7f, stretch)
            val dir = if (i % 2 == 0) 1f else -1f
            rotate(t * (28f + i * 18f) * dir, center) {
                drawPath(
                    p,
                    Brush.sweepGradient(listOf(c3, c4, c2, c5, c3), center = center),
                    alpha = 0.5f, blendMode = BlendMode.Screen
                )
            }
        }

        // rubans verticaux ondulants (les « W » lumineux de la vidéo), découpés dans la bulle
        clipPath(main) {
            for (i in 0 until 5) {
                val path = Path()
                val bx = cx + (i - 2) * big * 0.26f
                var y = cy - big * 0.85f
                var first = true
                while (y <= cy + big * 0.85f) {
                    val x = bx + big * 0.10f * sin(y / big * 3.2f + t * (0.9f + 0.25f * i) + i * 1.3f)
                    if (first) { path.moveTo(x, y); first = false } else path.lineTo(x, y)
                    y += big * 0.05f
                }
                drawPath(
                    path, c4.copy(alpha = 0.35f),
                    style = Stroke(width = big * 0.09f, cap = StrokeCap.Round), blendMode = BlendMode.Screen
                )
            }
        }

        // liseré lumineux sur le bord
        rotate(t * 25f, center) {
            drawPath(
                main,
                Brush.sweepGradient(
                    0f to Color.Transparent, 0.12f to c5, 0.28f to Color.Transparent,
                    0.60f to c4, 0.74f to Color.Transparent, 1f to Color.Transparent,
                    center = center
                ),
                alpha = 0.9f, style = Stroke(width = big * 0.035f)
            )
        }
    }
}
