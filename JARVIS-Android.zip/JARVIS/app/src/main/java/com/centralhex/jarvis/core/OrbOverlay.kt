package com.centralhex.jarvis.core

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import com.centralhex.jarvis.ui.components.OrbState
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/** Le petit hexagone animé dessiné à la main (plus léger qu'une vue Compose dans une fenêtre flottante). */
@SuppressLint("ViewConstructor")
class OrbView(context: Context) : View(context) {

    private var rotation = 0f
    private var pulse = 0f
    private var state = OrbState.IDLE
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val animator = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 3200
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            val speed = if (state == OrbState.IDLE) 1f else 2.6f
            rotation = (rotation + speed * 1.6f) % 360f
            pulse = (pulse + (if (state == OrbState.IDLE) 0.03f else 0.12f)) % 6.2832f
            invalidate()
        }
    }

    fun setOrbState(s: OrbState) { state = s }

    private fun accent() = when (state) {
        OrbState.IDLE -> Color.rgb(34, 211, 255)
        OrbState.LISTENING -> Color.rgb(255, 77, 94)
        OrbState.THINKING -> Color.rgb(255, 200, 87)
        OrbState.SPEAKING -> Color.rgb(46, 230, 168)
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); animator.start() }
    override fun onDetachedFromWindow() { animator.cancel(); super.onDetachedFromWindow() }

    private fun hex(canvas: Canvas, cx: Float, cy: Float, r: Float, rot: Float, p: Paint) {
        for (i in 0 until 6) {
            val a1 = Math.toRadians((rot + i * 60).toDouble())
            val a2 = Math.toRadians((rot + (i + 1) * 60).toDouble())
            canvas.drawLine(
                cx + r * cos(a1).toFloat(), cy + r * sin(a1).toFloat(),
                cx + r * cos(a2).toFloat(), cy + r * sin(a2).toFloat(), p
            )
        }
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = width / 2f - 6f
        val c = accent()
        val k = 0.85f + 0.15f * sin(pulse)

        // halo
        fill.shader = RadialGradient(cx, cy, r, intArrayOf(Color.argb(110, Color.red(c), Color.green(c), Color.blue(c)), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, r * k, fill)
        fill.shader = null
        // fond sombre du bouton
        fill.color = Color.argb(215, 4, 10, 22)
        canvas.drawCircle(cx, cy, r * 0.78f, fill)

        stroke.color = c; stroke.strokeWidth = 3.5f
        hex(canvas, cx, cy, r * 0.78f * k, rotation, stroke)
        stroke.color = Color.argb(150, 255, 255, 255); stroke.strokeWidth = 2f
        hex(canvas, cx, cy, r * 0.46f, -rotation * 1.4f, stroke)
        fill.color = c
        canvas.drawCircle(cx, cy, 4.5f + 2f * k, fill)
    }
}

/** Gère la boule flottante : affichage par-dessus les autres applis, déplaçable, un toucher = JARVIS s'active. */
class OrbOverlay(private val context: Context, private val onTap: () -> Unit) {

    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val prefs = context.getSharedPreferences("jarvis_orb", Context.MODE_PRIVATE)
    private var view: OrbView? = null
    private var params: WindowManager.LayoutParams? = null

    val isShown get() = view != null

    @SuppressLint("ClickableViewAccessibility")
    fun show() {
        if (view != null) return
        val size = (64 * context.resources.displayMetrics.density).toInt()
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("x", context.resources.displayMetrics.widthPixels - size - 16)
            y = prefs.getInt("y", context.resources.displayMetrics.heightPixels / 3)
        }
        val v = OrbView(context)
        v.setOrbState(JarvisBus.state.value)

        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - downX) > 14 || abs(e.rawY - downY) > 14) moved = true
                    if (moved) {
                        lp.x = startX + (e.rawX - downX).toInt()
                        lp.y = startY + (e.rawY - downY).toInt()
                        try { wm.updateViewLayout(v, lp) } catch (ex: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) prefs.edit().putInt("x", lp.x).putInt("y", lp.y).apply() else onTap()
                    true
                }
                else -> false
            }
        }
        try { wm.addView(v, lp); view = v; params = lp } catch (e: Exception) { view = null }
    }

    fun setState(s: OrbState) { view?.setOrbState(s) }

    fun hide() {
        view?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        view = null
    }
}
