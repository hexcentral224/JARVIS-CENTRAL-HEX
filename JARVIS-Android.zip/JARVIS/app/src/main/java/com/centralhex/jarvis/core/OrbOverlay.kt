package com.centralhex.jarvis.core

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import com.centralhex.jarvis.ui.components.OrbState
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/** Le petit hexagone animé : halo qui respire, ondes qui se propagent, hexagones qui tournent. */
@SuppressLint("ViewConstructor")
class OrbView(context: Context) : View(context) {

    private val d = resources.displayMetrics.density
    private var rotation2 = 0f
    private var pulse = 0f
    private var ripple = 0f
    private var state = OrbState.IDLE
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)

    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            val active = state != OrbState.IDLE
            rotation2 = (rotation2 + if (active) 4.2f else 1.5f) % 360f
            pulse = (pulse + if (active) 0.16f else 0.045f) % 6.2832f
            ripple = (ripple + if (active) 0.026f else 0.011f) % 1f
            invalidate()
        }
    }

    fun setOrbState(s: OrbState) {
        if (s == state) return
        state = s
        // petit « pop » à chaque changement d'état
        animate().scaleX(1.18f).scaleY(1.18f).setDuration(110).withEndAction {
            animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(2.2f)).start()
        }.start()
    }

    private fun accent() = when (state) {
        OrbState.IDLE -> Color.rgb(34, 211, 255)
        OrbState.LISTENING -> Color.rgb(255, 77, 94)
        OrbState.THINKING -> Color.rgb(255, 200, 87)
        OrbState.SPEAKING -> Color.rgb(46, 230, 168)
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); animator.start() }
    override fun onDetachedFromWindow() { animator.cancel(); super.onDetachedFromWindow() }

    private fun hex(canvas: Canvas, cx: Float, cy: Float, r: Float, rot: Float, p: Paint) {
        for (i in 0 until 6) {
            val a1 = Math.toRadians((rot + i * 60).toDouble())
            val a2 = Math.toRadians((rot + (i + 1) * 60).toDouble())
            canvas.drawLine(
                cx + r * cos(a1).toFloat(), cy + r * sin(a1).toFloat(),
                cx + r * cos(a2).toFloat(), cy + r * sin(a2).toFloat(), p
            )
        }
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val ro = width / 2f - 14f * d          // rayon du bouton ; la marge sert aux ondes et au rebond
        val c = accent()
        val k = 0.88f + 0.12f * sin(pulse)

        // ondes qui se propagent (3 anneaux décalés)
        stroke.strokeWidth = 2f * d
        for (i in 0 until 3) {
            val ph = (ripple + i / 3f) % 1f
            stroke.color = Color.argb(((1f - ph) * 150).toInt(), Color.red(c), Color.green(c), Color.blue(c))
            canvas.drawCircle(cx, cy, ro * (0.8f + 0.55f * ph), stroke)
        }
        // halo
        fill.shader = RadialGradient(cx, cy, ro * 1.25f, intArrayOf(Color.argb(120, Color.red(c), Color.green(c), Color.blue(c)), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, ro * 1.25f * k, fill)
        fill.shader = null
        // fond du bouton
        fill.color = Color.argb(225, 3, 9, 20)
        canvas.drawCircle(cx, cy, ro * 0.82f, fill)
        // anneau extérieur
        stroke.color = Color.argb(180, Color.red(c), Color.green(c), Color.blue(c)); stroke.strokeWidth = 1.5f * d
        canvas.drawCircle(cx, cy, ro * 0.82f, stroke)

        stroke.color = c; stroke.strokeWidth = 3f * d
        hex(canvas, cx, cy, ro * 0.62f * k, rotation2, stroke)
        stroke.color = Color.argb(160, 255, 255, 255); stroke.strokeWidth = 1.6f * d
        hex(canvas, cx, cy, ro * 0.38f, -rotation2 * 1.6f, stroke)
        fill.color = c
        canvas.drawCircle(cx, cy, (3.5f + 2.5f * k) * d, fill)
    }
}

/** Boule flottante : apparaît avec une animation, déplaçable, un toucher = JARVIS s'active. */
class OrbOverlay(private val context: Context, private val onTap: () -> Unit) {

    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val prefs = context.getSharedPreferences("jarvis_orb", Context.MODE_PRIVATE)
    private var view: OrbView? = null

    val isShown get() = view != null

    @SuppressLint("ClickableViewAccessibility")
    fun show() {
        if (view != null) return
        val size = (84 * context.resources.displayMetrics.density).toInt()
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("x", context.resources.displayMetrics.widthPixels - size - 8)
            y = prefs.getInt("y", context.resources.displayMetrics.heightPixels / 3)
        }
        val v = OrbView(context)

        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y; moved = false
                    v.animate().scaleX(0.85f).scaleY(0.85f).setDuration(90).start()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - downX) > 14 || abs(e.rawY - downY) > 14) moved = true
                    if (moved) {
                        lp.x = startX + (e.rawX - downX).toInt()
                        lp.y = startY + (e.rawY - downY).toInt()
                        try { wm.updateViewLayout(v, lp) } catch (ex: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(3f)).start()
                    if (e.action == MotionEvent.ACTION_UP) {
                        if (moved) prefs.edit().putInt("x", lp.x).putInt("y", lp.y).apply() else onTap()
                    }
                    true
                }
                else -> false
            }
        }
        try {
            wm.addView(v, lp)
            view = v
            // apparition : la boule jaillit en tournant, avec un rebond
            v.scaleX = 0f; v.scaleY = 0f; v.alpha = 0f; v.rotation = -220f
            v.animate().scaleX(1f).scaleY(1f).alpha(1f).rotation(0f)
                .setDuration(700).setInterpolator(OvershootInterpolator(1.8f)).start()
        } catch (e: Exception) { view = null }
    }

    fun setState(s: OrbState) { view?.setOrbState(s) }

    fun hide() {
        val v = view ?: return
        view = null
        v.animate().scaleX(0f).scaleY(0f).alpha(0f).rotation(180f).setDuration(240)
            .withEndAction { try { wm.removeView(v) } catch (e: Exception) {} }.start()
    }
}
