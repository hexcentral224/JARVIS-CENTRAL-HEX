package com.centralhex.jarvis.data

import android.content.Context
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

/**
 * Stockage local très simple : tout est gardé dans un seul fichier JSON,
 * dans le dossier privé de l'application (personne d'autre n'y a accès).
 * Pas de serveur, pas de compte : tout reste sur le téléphone.
 */
class LocalStore(context: Context) {
    private val file = File(context.filesDir, "jarvis_state.json")
    private val json = Json { ignoreUnknownKeys = true; prettyPrint = true }

    @Synchronized
    fun load(): AppState {
        if (!file.exists()) return AppState()
        return try {
            json.decodeFromString(AppState.serializer(), file.readText())
        } catch (e: Exception) {
            AppState() // fichier corrompu ou format trop ancien : on repart propre
        }
    }

    @Synchronized
    fun save(state: AppState) {
        file.writeText(json.encodeToString(state))
    }
}
