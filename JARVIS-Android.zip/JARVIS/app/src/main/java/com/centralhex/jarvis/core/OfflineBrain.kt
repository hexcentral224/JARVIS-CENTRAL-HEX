package com.centralhex.jarvis.core

/**
 * Petites réponses toutes faites, pour que JARVIS reste "vivant" même sans
 * connexion et sans clé IA : salutations, politesse, et quelques questions
 * simples. Si rien ne correspond, on laisse la main à l'IA (si disponible).
 */
object OfflineBrain {

    // Les phrases arrivent déjà nettoyées : minuscules, sans accents ni ponctuation, sans "moi"/"jarvis"/"stp"…
    private val rules: List<Pair<Regex, List<String>>> = listOf(
        Regex("""^(bonjour|salut|hello|coucou|yo|hey)$""") to listOf(
            "Bonjour. Je t'écoute.", "Salut. Que puis-je faire pour toi ?"
        ),
        Regex("""^(bonsoir)$""") to listOf("Bonsoir. Je suis là."),
        Regex("""^(bonne nuit)$""") to listOf("Bonne nuit. À demain."),
        Regex("""^(ca va|comment vas tu|comment ca va|tu vas bien|ca va bien|la forme)$""") to listOf(
            "Je fonctionne parfaitement, merci. Et toi ?"
        ),
        Regex("""^(qui es tu|t es qui|tu es qui|c est quoi ton nom|comment tu t appelles|comment t appelles tu)$""") to listOf(
            "Je suis JARVIS, ton assistant personnel, développé par CENTRAL-HEX 🇬🇳."
        ),
        Regex("""^(tu fais quoi|que fais tu|quoi de neuf)$""") to listOf(
            "Je veille, prêt à t'aider. Dis « aide » pour voir tout ce que je sais faire."
        ),
        Regex("""^(merci|merci beaucoup)$""") to listOf("Avec plaisir.", "Je t'en prie."),
        Regex("""^(au revoir|bye|a plus|a bientot)$""") to listOf("À bientôt."),
        Regex("""^(ok|d accord|super|cool|parfait)$""") to listOf("Très bien."),
        Regex("""^(je t aime|t es genial|tu es genial|bravo|bien joue)$""") to listOf(
            "C'est gentil, merci. Je fais de mon mieux."
        )
    )

    fun answer(normalizedText: String): String? =
        rules.firstOrNull { it.first.matches(normalizedText) }?.second?.random()
}
