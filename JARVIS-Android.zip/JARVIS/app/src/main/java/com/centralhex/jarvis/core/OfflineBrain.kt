package com.centralhex.jarvis.core

/**
 * Petites réponses toutes faites, pour que JARVIS reste "vivant" même sans
 * connexion et sans clé IA : salutations, politesse, et quelques questions
 * simples. Si rien ne correspond, on laisse la main à l'IA (si disponible).
 */
object OfflineBrain {

    private val rules: List<Pair<Regex, List<String>>> = listOf(
        Regex("""^(bonjour|salut|hello|coucou)[\s!.]*$""") to listOf(
            "Bonjour. Je t'écoute.", "Salut. Que puis-je faire pour toi ?"
        ),
        Regex("""^(bonsoir)[\s!.]*$""") to listOf("Bonsoir. Je suis là."),
        Regex("""^(ca va|comment vas[- ]tu|tu vas bien)[\s?!.]*$""") to listOf(
            "Je fonctionne parfaitement, merci. Et toi ?"
        ),
        Regex("""^(qui es[- ]tu|t'es qui|tu es qui)[\s?!.]*$""") to listOf(
            "Je suis JARVIS, ton assistant personnel, développé par CENTRAL-HEX 🇬🇳."
        ),
        Regex("""^merci[\s!.]*$""") to listOf("Avec plaisir.", "Je t'en prie."),
        Regex("""^(au revoir|bye|a plus)[\s!.]*$""") to listOf("À bientôt."),
        Regex("""^(je t'aime|t'es genial|tu es genial)[\s!.]*$""") to listOf(
            "C'est gentil, merci. Je fais de mon mieux."
        )
    )

    fun answer(normalizedText: String): String? =
        rules.firstOrNull { it.first.matches(normalizedText) }?.second?.random()
}
