package com.centralhex.jarvis.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColors = darkColorScheme(
    primary = HexWhite,
    secondary = HexGreen,
    background = HexBg,
    surface = HexCard,
    onPrimary = HexBg,
    onBackground = HexWhite,
    onSurface = HexWhite,
    outline = HexLine
)

private val LightColors = lightColorScheme(
    primary = HexTextLight,
    secondary = HexGreen,
    background = HexBgLight,
    surface = HexCardLight,
    onPrimary = HexBgLight,
    onBackground = HexTextLight,
    onSurface = HexTextLight,
    outline = HexLineLight
)

@Composable
fun JarvisTheme(dark: Boolean = true, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        typography = JarvisTypography,
        content = content
    )
}
