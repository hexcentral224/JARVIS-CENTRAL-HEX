package com.centralhex.jarvis.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val HudColors = darkColorScheme(
    primary = HudCyan,
    secondary = HudGold,
    tertiary = HudBlue,
    background = HudBg,
    surface = HudPanel,
    surfaceVariant = HudPanel,
    onPrimary = HudBg,
    onSecondary = HudBg,
    onBackground = HudText,
    onSurface = HudText,
    onSurfaceVariant = HudMuted,
    outline = HudLine,
    secondaryContainer = HudLine,
    onSecondaryContainer = HudText
)

@Composable
@Suppress("UNUSED_PARAMETER")
fun JarvisTheme(dark: Boolean = true, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = HudColors,
        typography = JarvisTypography,
        content = content
    )
}
