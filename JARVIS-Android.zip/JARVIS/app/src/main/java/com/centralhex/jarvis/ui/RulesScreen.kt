package com.centralhex.jarvis.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.centralhex.jarvis.data.AutomationRule

private val actionTypes = listOf(
    "open_app" to "Ouvrir une application",
    "call" to "Appeler un numéro / contact",
    "sms" to "Envoyer un SMS",
    "say" to "Juste répondre un message"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RulesScreen(
    rules: List<AutomationRule>,
    onAdd: (AutomationRule) -> Unit,
    onDelete: (Long) -> Unit,
    onBack: () -> Unit
) {
    var trigger by remember { mutableStateOf("") }
    var actionType by remember { mutableStateOf(actionTypes.first().first) }
    var actionValue by remember { mutableStateOf("") }
    var smsBody by remember { mutableStateOf("") }
    var menuOpen by remember { mutableStateOf(false) }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("Automatisations") },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Retour") } }
        )
    }) { padding ->
        Column(Modifier.padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Quand je dis…", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(
                value = trigger, onValueChange = { trigger = it },
                placeholder = { Text("ex. : bonsoir, je rentre") },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )

            Text("…alors JARVIS fait :", style = MaterialTheme.typography.titleMedium)
            ExposedDropdownMenuBox(expanded = menuOpen, onExpandedChange = { menuOpen = it }) {
                OutlinedTextField(
                    value = actionTypes.first { it.first == actionType }.second,
                    onValueChange = {}, readOnly = true,
                    modifier = Modifier.menuAnchor().fillMaxWidth()
                )
                ExposedDropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    actionTypes.forEach { (type, label) ->
                        DropdownMenuItem(text = { Text(label) }, onClick = { actionType = type; menuOpen = false })
                    }
                }
            }

            val valueLabel = when (actionType) {
                "open_app" -> "Nom de l'application"
                "call" -> "Numéro ou nom du contact"
                "sms" -> "Numéro ou nom du contact"
                else -> "Message à dire"
            }
            OutlinedTextField(
                value = actionValue, onValueChange = { actionValue = it },
                label = { Text(valueLabel) }, singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            if (actionType == "sms") {
                OutlinedTextField(
                    value = smsBody, onValueChange = { smsBody = it },
                    label = { Text("Contenu du SMS") }, modifier = Modifier.fillMaxWidth()
                )
            }

            Button(
                enabled = trigger.isNotBlank() && actionValue.isNotBlank(),
                onClick = {
                    onAdd(AutomationRule(trigger = trigger, actionType = actionType, actionValue = actionValue, smsBody = smsBody))
                    trigger = ""; actionValue = ""; smsBody = ""
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Ajouter la règle") }

            Divider(Modifier.padding(vertical = 6.dp))
            Text("Règles actives (${rules.size})", style = MaterialTheme.typography.titleMedium)

            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(rules, key = { it.id }) { rule ->
                    Card(shape = RoundedCornerShape(14.dp)) {
                        Row(
                            Modifier.fillMaxWidth().padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text("« ${rule.trigger} »", style = MaterialTheme.typography.bodyLarge)
                                Text(
                                    actionTypes.first { it.first == rule.actionType }.second + " → ${rule.actionValue}",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                            IconButton(onClick = { onDelete(rule.id) }) {
                                Icon(Icons.Filled.Delete, contentDescription = "Supprimer")
                            }
                        }
                    }
                }
            }
        }
    }
}
