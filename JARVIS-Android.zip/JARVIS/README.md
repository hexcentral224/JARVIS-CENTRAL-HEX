<div align="center">

<img src="https://capsule-render.vercel.app/api?type=waving&color=gradient&customColorList=6,11,18&height=200&section=header&text=JARVIS&fontSize=60&fontColor=ffffff&animation=fadeIn&fontAlignY=36&desc=Assistant%20Android%20hors%20ligne%20%E2%80%A2%20con%C3%A7u%20par%20CENTRAL-HEX&descSize=18&descAlignY=58" alt="JARVIS" width="100%"/>

<img src="https://readme-typing-svg.demolab.com?font=Fira+Code&weight=600&size=22&duration=3000&pause=900&color=00E5FF&center=true&vCenter=true&width=680&height=50&lines=Dis+%C2%AB+JARVIS+%C2%BB%2C+m%C3%AAme+%C3%A9cran+%C3%A9teint;Fonctionne+sans+connexion+internet;Appeler+%E2%80%A2+SMS+%E2%80%A2+Rappels+%E2%80%A2+Notes+%E2%80%A2+Calcul;Con%C3%A7u+par+CENTRAL-HEX+%F0%9F%87%AC%F0%9F%87%B3" alt="Animation"/>

![Kotlin](https://img.shields.io/badge/Kotlin-100%25-8A5BFF?style=for-the-badge&logo=kotlin&logoColor=white)
![Android](https://img.shields.io/badge/Android-8.0%2B-00E5FF?style=for-the-badge&logo=android&logoColor=white)
![Hors ligne](https://img.shields.io/badge/mode-hors%20ligne-27D17F?style=for-the-badge)

</div>

---

## ✨ JARVIS, par CENTRAL-HEX 🇬🇳

JARVIS est un assistant personnel pour Android, dans l'esprit CENTRAL-HEX :
noir et blanc, hexagones, sobre et direct. Tu lui parles, il te répond, et il
agit directement sur l'appareil. Développé par **CENTRAL-HEX**.

> 🎙️ **Dis « JARVIS » n'importe quand** — appli fermée, écran éteint — l'écran
> **s'allume tout seul** avec une animation (l'hexagone qui pulse, comme un
> robot qui se réveille), il t'écoute et te répond à voix haute. Aucune
> donnée ne quitte le téléphone, sauf pour les questions ouvertes envoyées à
> l'IA (si tu actives une clé gratuite).

## 🎨 Le design

- **Accueil** : un tableau de bord dans le style de la maquette CENTRAL-HEX —
  l'hexagone JARVIS animé, l'état du téléphone (batterie, Wi-Fi, données
  mobiles), des actions rapides (ouvrir une appli, appeler, créer une alarme,
  automatisations…), le chat, le journal des dernières commandes, et des
  interrupteurs rapides (mot de réveil, voix, thème).
- **Automatisations** et **Réglages** : deux autres onglets, accessibles en
  bas de l'écran.
- Sur téléphone, il n'y a pas de barre latérale fixe comme sur un écran
  d'ordinateur — à la place, une **barre de navigation en bas** (Accueil ·
  Automatisations · Réglages), c'est l'équivalent naturel sur mobile.
- Un **thème clair** existe aussi, à activer dans Réglages ou directement
  depuis l'accueil.

## 🎙️ L'écran de réveil : l'écran s'allume, comme un robot

1. Ouvre ⚙️ **Réglages** (ou l'interrupteur sur l'accueil) et active
   *« Mot « JARVIS » »*.
2. Ferme l'application, verrouille l'écran, mets le téléphone dans ta poche.
3. Dis **« JARVIS »** → **l'écran s'allume tout seul**, par-dessus l'écran
   verrouillé (le téléphone reste verrouillé, JARVIS s'affiche juste
   par-dessus), avec l'hexagone qui pulse et *« Je vous écoute… »*.
4. Donne ta demande → l'hexagone change de rythme pendant qu'il réfléchit,
   puis répond à voix haute et à l'écrit. L'écran se referme tout seul après
   quelques secondes (ou appuie sur le micro pour reparler).

Deux mécanismes Android travaillent ensemble pour ça :
- `WakeWordService` : un service qui tourne en permanence et attend juste le
  mot « JARVIS ». `android:stopWithTask="false"` l'empêche de s'arrêter quand
  tu fermes l'appli depuis les applications récentes.
- `WakeActivity` : dès que le mot est entendu, elle s'ouvre en **notification
  plein écran** — le même mécanisme que les appels entrants et les alarmes —
  ce qui allume l'écran avec une vraie interface, pas juste une notification.

⚠️ **Deux réglages à vérifier une fois, pour que ce soit fiable :**
- **Notifications plein écran** : sur Android 14+, va dans
  **Paramètres ▸ Applis ▸ JARVIS ▸ Notifications plein écran** et autorise-les
  (Android les bloque par défaut pour les nouvelles applications).
- **Batterie** : sur Xiaomi, Huawei, Oppo, Samsung (mode économie), va dans
  **Paramètres ▸ Batterie ▸ JARVIS** et désactive l'optimisation, sinon le
  système coupe le micro après quelques minutes écran éteint.

Une petite notification reste aussi affichée en continu pendant que JARVIS
veille — Android l'impose pour qu'un micro ne puisse jamais écouter en
cachette, sur aucune application, impossible à enlever.

## 📴 Fonctionne sans connexion internet

Toutes ces commandes répondent **instantanément, sans internet et sans clé IA** :

| Catégorie | Exemples de phrases |
|---|---|
| 📞 Téléphone | *« appelle Awa »*, *« envoie un sms à Awa disant je suis en route »* |
| 📱 Applications | *« ouvre WhatsApp »* |
| ⏰ Temps | *« règle une alarme à 7h30 »*, *« rappelle-moi dans 10 min de sortir le linge »*, *« lance un minuteur de 5 minutes »* |
| 🕒 Infos | *« quelle heure est-il »*, *« quel jour sommes-nous »*, *« batterie »* |
| 🔦 Téléphone | *« allume la lampe torche »*, *« monte le volume »*, *« ouvre le wifi »*, *« ouvre le bluetooth »*, *« active le mode avion »* |
| 📷 Médias | *« ouvre l'appareil photo »*, *« où suis-je »* (carte), *« joue de la musique »*, *« chanson suivante »* |
| 🔇 Son | *« active le mode silencieux »*, *« active ne pas déranger »* |
| 🔒 Sécurité | *« verrouille l'écran »* (après activation une fois dans Réglages) |
| 📝 Notes | *« note acheter du pain »*, *« lis mes notes »*, *« efface mes notes »* |
| 🧮 Calcul | *« calcule 12 fois 15 »*, *« combien font 20 plus 5 »* |
| 🗣️ Petites conversations | *« bonjour »*, *« merci »*, *« qui es-tu »*, *« qui t'a créé »* |
| ⚙️ Automatisations | des règles « quand je dis X, JARVIS fait Y » (écran *Automatisations*) |
| 🔈 Divertissement | *« stop »* / *« tais-toi »* coupe la voix immédiatement |

Seules les **questions ouvertes** (« explique-moi... », « écris-moi... ») ont
besoin d'internet et d'une clé IA gratuite : un assistant qui comprend
absolument tout ne peut pas tourner entièrement sur un téléphone, il lui faut
un serveur quelque part. Sans connexion, JARVIS te le dit simplement, il ne
plante jamais.

## ⚠️ Avant de commencer

Ce code a été écrit et relu avec soin, mais **pas compilé** dans
l'environnement où il a été créé (pas d'Android Studio ni de téléphone
disponibles ici). Ouvre le projet dans Android Studio et corrige les
éventuelles erreurs de compilation avant de l'installer — envoie-moi le
message d'erreur si besoin, je corrige.

## 🛠️ Installation

1. Installe **[Android Studio](https://developer.android.com/studio)** (gratuit).
2. **Fichier ▸ Ouvrir** et choisis le dossier `JARVIS`.
3. Laisse Android Studio télécharger Gradle et les dépendances.
4. Branche un téléphone Android (mode développeur + débogage USB) ou crée un émulateur.
5. **Run ▸ app** (▶️).
6. Accorde les permissions demandées (micro, contacts, téléphone, SMS, notifications).

## 🔑 Activer l'intelligence artificielle (facultatif)

1. Crée un compte gratuit sur **[console.groq.com](https://console.groq.com)** (ou openrouter.ai).
2. Génère une clé API.
3. Dans l'application : ⚙️ **Réglages ▸ Clé API**, puis **Enregistrer**.

Sans clé, toutes les commandes du tableau ci-dessus fonctionnent quand même.

## 🔐 Permissions demandées

| Permission | Pourquoi |
|---|---|
| Micro | Te comprendre, y compris en arrière-plan pour le mot de réveil |
| Contacts | Reconnaître un nom (« appelle Awa ») |
| Téléphone | Appeler directement |
| SMS | Envoyer un SMS directement |
| Notifications | Rappels + notification du mode "écoute permanente" |
| Ne pas déranger (optionnelle) | Changer le mode sonore — demandée seulement à l'usage |
| Administration (optionnelle) | Verrouiller l'écran — à activer soi-même dans Réglages |

Si tu refuses une permission, JARVIS n'échoue pas : il ouvre l'application
ou l'écran correspondant à la place.

## 🧩 Structure du projet

```
JARVIS/
├── app/src/main/java/com/centralhex/jarvis/
│   ├── MainActivity.kt            # permissions + navigation
│   ├── WakeActivity.kt            # écran plein écran, animation de réveil
│   ├── core/
│   │   ├── AiClient.kt            # appel à l'IA (format OpenAI)
│   │   ├── CommandRouter.kt       # comprend les phrases avant d'appeler l'IA
│   │   ├── OfflineBrain.kt        # petites réponses sans connexion
│   │   ├── Calculator.kt          # calcul hors ligne
│   │   ├── DeviceActions.kt       # tout ce qui agit sur le téléphone
│   │   ├── VoiceManager.kt        # micro + voix, appli ouverte
│   │   ├── WakeWordService.kt     # écoute "JARVIS" en continu, écran éteint
│   │   ├── JarvisDeviceAdminReceiver.kt
│   │   └── ReminderScheduler.kt / ReminderReceiver.kt
│   ├── data/
│   │   ├── Models.kt              # messages, règles, notes, journal, réglages
│   │   └── LocalStore.kt          # sauvegarde locale (fichier JSON privé)
│   └── ui/
│       ├── HomeScreen.kt          # tableau de bord façon CENTRAL-HEX
│       ├── SettingsScreen.kt / RulesScreen.kt
│       ├── components/HexOrb.kt   # l'hexagone animé, réutilisé partout
│       └── JarvisViewModel.kt
└── app/src/main/AndroidManifest.xml
```

## ➕ Ajouter une commande hors ligne

Dans `core/CommandRouter.kt`, ajoute une expression régulière et relie-la à
une fonction de `DeviceActions.kt` (ou à `OfflineBrain.kt` pour une simple
réponse toute faite). Les commandes locales répondent instantanément, sans
passer par l'IA — c'est ce qui rend JARVIS utilisable hors ligne.

## ❓ Questions fréquentes

<details>
<summary><b>JARVIS ne réagit pas quand je dis "JARVIS" écran éteint</b></summary>

Vérifie que l'écoute permanente est activée dans Réglages, et désactive
l'optimisation de batterie pour JARVIS (Paramètres du téléphone ▸ Batterie).
Certains constructeurs sont très agressifs pour économiser la batterie.
</details>

<details>
<summary><b>Il dit qu'il n'a pas de clé IA</b></summary>

Ouvre ⚙️ Réglages et colle une clé API gratuite — uniquement nécessaire pour
les questions qui ne sont pas des commandes du tableau ci-dessus.
</details>

<details>
<summary><b>"Verrouille l'écran" ne marche pas</b></summary>

Active d'abord « Verrouillage à distance » dans Réglages : Android exige une
autorisation spéciale, à accorder une seule fois.
</details>

<details>
<summary><b>Le mode silencieux / Ne pas déranger ne change pas</b></summary>

La première fois, JARVIS ouvre l'écran d'autorisation d'Android : active-le
pour JARVIS, puis redemande la commande.
</details>

---

<div align="center">

✦ Conçu et développé par **CENTRAL-HEX** 🇬🇳 ✦

*Où la technologie rencontre la créativité.*

<img src="https://capsule-render.vercel.app/api?type=waving&color=gradient&customColorList=6,11,18&height=100&section=footer" width="100%" alt=""/>

</div>
